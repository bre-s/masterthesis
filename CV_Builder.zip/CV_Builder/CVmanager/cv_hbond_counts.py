from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


def _hb_mask_for_center(
    coords: np.ndarray,
    H1: int,
    O0: int,
    H2: int,
    O_all: np.ndarray,
    R_OO_max: float,
    angle_min_deg: float,
    L: Optional[float],
) -> np.ndarray:
    """
    Boolean mask over O_all for oxygens that are H-bonded ACCEPTORS
    when O0 is donor (H1/H2 as donor hydrogens).
    """
    cos_cut = float(np.cos(np.deg2rad(angle_min_deg)))
    rcut2 = float(R_OO_max ** 2)

    Opos0 = coords[O0]
    d = coords[O_all] - Opos0
    if L is not None and L > 0:
        d = d - np.rint(d / L) * L

    r2 = np.einsum("ij,ij->i", d, d)
    cand = (r2 <= rcut2) & (r2 > 0.0)
    if not np.any(cand):
        return np.zeros_like(cand, dtype=bool)

    u = np.zeros_like(d)
    nz = np.linalg.norm(d[cand], axis=1)
    u[cand] = (d[cand].T / (nz + 1e-20)).T

    v1 = _unit(_pbc_delta(coords[H1] - Opos0, L))
    v2 = _unit(_pbc_delta(coords[H2] - Opos0, L))
    ang_ok = (u @ v1 >= cos_cut) | (u @ v2 >= cos_cut)
    return cand & ang_ok



# ----------------------------------------------------------------------
# 1) AcceptorsCountCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class AcceptorsCountCV:
    """
    Count of accepted H-bonds where the center oxygen acts as donor.

    Center oxygen:
        if use_donor_O=True  -> rc.O_d
        else                 -> rc.O_a

    Output:
        [n_acceptors]
    """
    name: str = "acceptors_count"
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("n_acceptors",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        wtrip = inputs.water_triplets   # rows: H1, O, H2

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        mask = _hb_mask_for_center(
            inputs.coords, h1, o0, h2, O_all,
            self.R_OO_max, self.angle_min_deg,
            getattr(inputs, "box", None)
        )
        n_acc = float(np.count_nonzero(mask))
        return np.array([n_acc], dtype=float)



# -------------------------------------------------------------------------
# 2) DonorsCountCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class DonorsCountCV:
    """
    Count of H-bonds donated *to* the center oxygen (center as acceptor).

    For each water j (H1, Oj, H2):
        - check if center oxygen lies within R_OO_max of Oj
        - check if center lies inside donor-cone (angle at Oj) for H1 or H2

    Output:
        [n_donors]
    """
    name: str = "donors_count"
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("n_donors",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        target_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        wtrip = inputs.water_triplets  # H1, O, H2 rows
        coords = inputs.coords
        L = getattr(inputs, "box", None)

        cos_cut = float(np.cos(np.deg2rad(self.angle_min_deg)))
        rcut2 = float(self.R_OO_max ** 2)

        count = 0
        for (h1, oi, h2) in wtrip.astype(int):
            if oi == target_O:
                continue

            d = _pbc_delta(coords[target_O] - coords[oi], L)
            r2 = float(d @ d)
            if r2 <= 0.0 or r2 > rcut2:
                continue

            u = d / (np.linalg.norm(d) + 1e-20)
            v1 = _pbc_delta(coords[h1] - coords[oi], L)
            v1 /= (np.linalg.norm(v1) + 1e-20)
            v2 = _pbc_delta(coords[h2] - coords[oi], L)
            v2 /= (np.linalg.norm(v2) + 1e-20)

            if (u @ v1) >= cos_cut or (u @ v2) >= cos_cut:
                count += 1

        return np.array([float(count)], dtype=float)
    
# -------------------------------------------------------------------------
# 3) DonorAcceptorImbalanceCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class DonorAcceptorImbalanceCV:
    """
    Δn = n_acceptors - n_donors for det reaktive oksygenet (donor eller akseptor).
    H-bindinger definert geometrisk:
        - R_OO <= R_OO_max
        - vinkel ved donor >= angle_min_deg

    Params:
        R_OO_max: maks O–O avstand (Å)
        angle_min_deg: min donor-vinkel (grader)
        use_donor_O: True → bruk rc.O_d, False → bruk rc.O_a

    Output:
        values[0] = Δn = n_a - n_d
    """
    name: str = "donor_acceptor_imbalance"

    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    use_donor_O: bool = True

    labels: tuple[str, ...] = field(default=("delta_n",), init=False)

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L = getattr(inputs, "box", None)
        water_triplets: np.ndarray = inputs.water_triplets  # (nW,3)
        rc = getattr(inputs, "reaction", None)

        if rc is None:
            return np.array([np.nan], dtype=float)

        O0 = int(rc.O_d if self.use_donor_O else rc.O_a)

        # Bygg O->(H1,H2) map fra triplets (H1,O,H2)
        O_all = water_triplets[:, 1].astype(int)
        H_pairs_by_O: Dict[int, Tuple[int, int]] = {
            int(O): (int(h1), int(h2)) for (h1, O, h2) in water_triplets
        }

        if O0 not in H_pairs_by_O:
            return np.array([np.nan], dtype=float)

        R2_max = float(self.R_OO_max ** 2)
        cos_min = float(np.cos(np.deg2rad(self.angle_min_deg)))

        Opos_all = coords[O_all]
        O0_pos = coords[O0]

        # Dist og vektorer fra O0 til alle andre O
        dO = _pbc_delta(Opos_all - O0_pos, L)
        r2 = np.einsum("ij,ij->i", dO, dO)
        # Kandidat-oks: innen cutoff og ikke deg selv
        mask = (r2 <= R2_max) & (r2 > 0.0)
        cand_idx = np.where(mask)[0]

        n_d = 0  # O0 donerer
        n_a = 0  # O0 aksepterer

        # Først: donor-rollen til O0
        H1_O0, H2_O0 = H_pairs_by_O[O0]
        v1 = _unit(_pbc_delta(coords[H1_O0] - O0_pos, L))
        v2 = _unit(_pbc_delta(coords[H2_O0] - O0_pos, L))

        for k in cand_idx:
            Oj = int(O_all[k])
            u = _unit(dO[k])
            # O0 som donor til Oj
            if (v1 @ u) >= cos_min or (v2 @ u) >= cos_min:
                n_d += 1

        # Så: O0 som akseptor fra andre vanner
        for Oj in O_all:
            if int(Oj) == O0:
                continue
            Oj = int(Oj)
            Oj_pos = coords[Oj]
            d = _pbc_delta(O0_pos - Oj_pos, L)
            if np.dot(d, d) > R2_max or np.dot(d, d) == 0.0:
                continue
            u = _unit(d)
            h1, h2 = H_pairs_by_O[Oj]
            v1 = _unit(_pbc_delta(coords[h1] - Oj_pos, L))
            v2 = _unit(_pbc_delta(coords[h2] - Oj_pos, L))
            if (v1 @ u) >= cos_min or (v2 @ u) >= cos_min:
                n_a += 1

        delta_n = float(n_a - n_d)
        return np.array([delta_n], dtype=float)
