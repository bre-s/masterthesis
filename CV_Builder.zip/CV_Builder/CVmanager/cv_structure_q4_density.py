from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _spherical_angles(vec: np.ndarray) -> Tuple[float, float]:
    """
    Returner (theta, phi) for en 3D-vektor:
        theta: polarvinkel  [0, pi]
        phi  : azimuth      [0, 2*pi)
    """
    x, y, z = vec
    r = np.linalg.norm(vec)
    if r == 0:
        return 0.0, 0.0
    theta = np.arccos(np.clip(z / r, -1.0, 1.0))
    phi = np.arctan2(y, x)
    if phi < 0:
        phi += 2.0 * np.pi
    return theta, phi


def _Y_4m(theta: float, phi: float) -> np.ndarray:
    """
    En enkel (ikke perfekt normalisert) kompleks sfærisk harmonisk-vektor for l=4, m=-4..4.

    For ML-formål er relative forskjeller viktigst, ikke absolutt norm.
    """
    # precompute trig
    c = np.cos(theta)
    s = np.sin(theta)
    eip = np.exp(1j * phi)
    eim = np.exp(-1j * phi)

    # Legendre-lignende uttrykk (skalert)
    # Vi gir oss med grove uttrykk for P_4^m(c) og fokuserer på konsistens.
    P40 = (35 * c**4 - 30 * c**2 + 3) / 8.0
    P41 = -2.5 * c * (7 * c**2 - 3) * s      # ~ P_4^1
    P42 = (105 * c**2 - 15) * (s**2) / 2.0   # ~ P_4^2
    P43 = -35 * c * (s**3)                   # ~ P_4^3
    P44 = 35 * (s**4)                        # ~ P_4^4

    Y = np.zeros(9, dtype=complex)

    # m = 0
    Y[4] = P40

    # m = ±1
    Y[5] = P41 * eip
    Y[3] = np.conj(Y[5])

    # m = ±2
    Y[6] = P42 * (eip ** 2)
    Y[2] = np.conj(Y[6])

    # m = ±3
    Y[7] = P43 * (eip ** 3)
    Y[1] = np.conj(Y[7])

    # m = ±4
    Y[8] = P44 * (eip ** 4)
    Y[0] = np.conj(Y[8])

    return Y


# ----------------------------------------------------------------------
# 1) SteinhardtQ4_CV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class SteinhardtQ4_CV:
    """
    Steinhardt-lignende Q4 rundt center-O (donor eller akseptor).

    For n nærmeste O-naboer:

        q_4m = (1/n) Σ_j Y_4m(theta_j, phi_j)
        Q4   = sqrt( Σ_m |q_4m|^2 )

    (her bruker vi en litt fri normalisering, men konsistent)

    Output:
        [Q4]
    """
    name: str = "steinhardt_q4"
    k_neigh: int = 12
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("Q4",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)

        O_all = wtrip[:, 1].astype(int)
        center_pos = coords[center_O]

        # distanser til alle andre O
        d = coords[O_all] - center_pos
        if L is not None and L > 0:
            d = d - np.rint(d / L) * L
        r = np.linalg.norm(d, axis=1)
        # ekskluder self
        mask = (O_all != center_O)
        if not np.any(mask):
            return np.array([np.nan], dtype=float)

        d = d[mask]
        r = r[mask]

        if d.shape[0] == 0:
            return np.array([np.nan], dtype=float)

        idx = np.argsort(r)[: min(self.k_neigh, d.shape[0])]
        d_sel = d[idx]

        n = d_sel.shape[0]
        if n == 0:
            return np.array([np.nan], dtype=float)

        q4m = np.zeros(9, dtype=complex)
        for vec in d_sel:
            theta, phi = _spherical_angles(vec)
            q4m += _Y_4m(theta, phi)
        q4m /= n

        Q4 = float(np.sqrt(np.sum(np.abs(q4m) ** 2)))
        return np.array([Q4], dtype=float)


# ----------------------------------------------------------------------
# 2) LocalDensityCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class LocalDensityCV:
    """
    Lokalt koordinasjonstall / tetthet: antall O innen radius R rundt center-O.

    Center oxygen:
        if use_donor_O=True  -> rc.O_d
        else                 -> rc.O_a

    Output:
        [N_O_within_R]
    """
    name: str = "local_density"
    R: float = 4.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("N_O_within_R",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)

        O_all = wtrip[:, 1].astype(int)
        center_pos = coords[center_O]

        d = coords[O_all] - center_pos
        if L is not None and L > 0:
            d = d - np.rint(d / L) * L
        r2 = np.einsum("ij,ij->i", d, d)
        mask = (O_all != center_O) & (r2 <= self.R ** 2)

        return np.array([float(np.count_nonzero(mask))], dtype=float)


# ----------------------------------------------------------------------
# 3) LocalSofR_CV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class LocalSofR_CV:
    """
    Enkel RDF-/S(r)-lignende feature:

    Del 0..R_max inn i N bins med bredde dr, og returner antall O-naboer
    i hver bin (utenom center-O). Dette gir en vektor [N_bin0, N_bin1, ...].

    Output shape:
        (n_bins,) der n_bins = int(R_max/dr)
    """
    name: str = "local_S_of_r"
    R_max: float = 5.0
    dr: float = 0.2
    use_donor_O: bool = True
    labels: Tuple[str, ...] = field(init=False)

    def __post_init__(self):
        n_bins = int(self.R_max / self.dr)
        cols = [f"S_r_bin{i}" for i in range(n_bins)]
        object.__setattr__(self, "labels", tuple(cols))

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.full((len(self.labels),), np.nan, dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)

        O_all = wtrip[:, 1].astype(int)
        center_pos = coords[center_O]

        d = coords[O_all] - center_pos
        if L is not None and L > 0:
            d = d - np.rint(d / L) * L
        r = np.linalg.norm(d, axis=1)
        mask = (O_all != center_O) & (r > 0.0) & (r <= self.R_max)

        r_sel = r[mask]
        n_bins = len(self.labels)
        hist, _ = np.histogram(r_sel, bins=n_bins, range=(0.0, self.R_max))

        return hist.astype(float)


# -------------------------------------------------------------------------
# 4) TetrahedralityQ_CV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class TetrahedralityQ_CV:
    """
    Klassisk tetraedralitetsparameter q rundt det reaktive oksygenet.
    Definisjon:
        q = 1 - (3/8) * sum_{i<j} (cos(ψ_ij) + 1/3)^2
        der ψ_ij er vinkelen mellom vektorene fra O0 til de fire nærmeste O-naboene.

    Params:
        use_donor_O: True → bruk rc.O_d, False → bruk rc.O_a

    Output:
        values[0] = q (NaN hvis færre enn 4 naboer)
    """
    name: str = "tetrahedrality_q"

    use_donor_O: bool = True

    labels: tuple[str, ...] = field(default=("q_tetra",), init=False)

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L = getattr(inputs, "box", None)
        water_triplets: np.ndarray = inputs.water_triplets  # (nW,3)
        rc = getattr(inputs, "reaction", None)

        if rc is None:
            return np.array([np.nan], dtype=float)

        O0 = int(rc.O_d if self.use_donor_O else rc.O_a)

        # Alle vannoksigener
        O_all = water_triplets[:, 1].astype(int)
        if O0 not in O_all:
            return np.array([np.nan], dtype=float)

        Opos_all = coords[O_all]
        O0_pos = coords[O0]

        # Avstander fra O0 til andre O (MIC)
        d = _pbc_delta(Opos_all - O0_pos, L)
        r2 = np.einsum("ij,ij->i", d, d)

        # Ekskluder O0 selv
        mask = r2 > 0.0
        d = d[mask]
        r2 = r2[mask]
        if d.shape[0] < 4:
            return np.array([np.nan], dtype=float)

        # Velg 4 nærmeste naboer
        idx_sorted = np.argsort(r2)
        idx4 = idx_sorted[:4]
        v = d[idx4]                    # (4,3)
        v = v / (np.linalg.norm(v, axis=1, keepdims=True) + 1e-20)

        # Beregn q
        cos_psi = []
        for i in range(4):
            for j in range(i + 1, 4):
                cos_ij = float(np.dot(v[i], v[j]))
                cos_psi.append(cos_ij)

        q = 1.0
        s = 0.0
        for c in cos_psi:
            s += (c + 1.0 / 3.0) ** 2
        q -= (3.0 / 8.0) * s

        return np.array([float(q)], dtype=float)
