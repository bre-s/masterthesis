from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    """Minimum image convention for a displacement vector d in a cubic box of length L."""
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)

def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


# -------------------------------------------------------------------------
# 1) DipoleAlongAxisCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class DipoleAlongAxisCV:
    """
    Project total dipole (from CP2K per-frame dipole file) onto the reaction axis O_d -> O_a.

    Expects:
        inputs.dipole_total : array-like with shape (3,)   # total dipole vector
        inputs.coords       : invariant coordinates (N,3)
        inputs.reaction     : ReactionCenter-like with O_d, O_a
        inputs.box          : box length (float) or None

    Output:
        np.array([mu_parallel])  # scalar projection
    """
    name: str = "dipole_along_axis"
    labels: Tuple[str, ...] = ("mu_parallel",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        dip = getattr(inputs, "dipole_total", None)
        if rc is None or dip is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)

        O_d = int(rc.O_d)
        O_a = int(rc.O_a)

        axis = _pbc_delta(coords[O_a] - coords[O_d], L)
        norm = float(np.linalg.norm(axis))
        if norm == 0.0:
            return np.array([np.nan], dtype=float)
        u = axis / norm

        mu = np.asarray(dip, dtype=float).reshape(-1)
        if mu.size < 3:
            return np.array([np.nan], dtype=float)

        mu_par = float(np.dot(mu[:3], u))
        return np.array([mu_par], dtype=float)


# -------------------------------------------------------------------------
# 2) ForcesAlongAxisCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class ForcesAlongAxisCV:
    """
    Project atomic forces for the key triplet (O_d, H*, O_a) onto the reaction axis O_d -> O_a.

    Expects:
        inputs.forces_invariant : (N,3) forces in invariant order
        inputs.coords           : (N,3) coordinates in invariant order
        inputs.reaction         : ReactionCenter-like with O_d, O_a, Hs
        inputs.box              : box length or None

    Output:
        [F_Od_parallel, F_Hstar_parallel, F_Oa_parallel]
    """
    name: str = "forces_along_axis"
    labels: Tuple[str, ...] = ("F_Od_parallel", "F_Hstar_parallel", "F_Oa_parallel")

    def compute(self, inputs) -> np.ndarray:
        frc = getattr(inputs, "forces_invariant", None)
        rc = getattr(inputs, "reaction", None)
        if frc is None or rc is None:
            return np.array([np.nan, np.nan, np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)

        forces = np.asarray(frc, dtype=float)
        N = coords.shape[0]

        if forces.shape != (N, 3):
            print(
                f"[ForcesAlongAxisCV] Shape mismatch: coords ({N},3), "
                f"forces {forces.shape}. Returning NaN."
            )
            return np.array([np.nan], dtype=float)

        O_d = int(rc.O_d)
        O_a = int(rc.O_a)
        Hs = int(getattr(rc, "Hs", -1))

        if Hs < 0 or Hs >= frc.shape[0]:
            return np.array([np.nan, np.nan, np.nan], dtype=float)

        axis = _pbc_delta(coords[O_a] - coords[O_d], L)
        norm = float(np.linalg.norm(axis))
        if norm == 0.0:
            return np.array([np.nan, np.nan, np.nan], dtype=float)
        u = axis / norm

        def proj(i: int) -> float:
            f = np.asarray(frc[i], dtype=float).reshape(3)
            return float(np.dot(f, u))

        return np.array([proj(O_d), proj(Hs), proj(O_a)], dtype=float)


# -------------------------------------------------------------------------
# 3) HOMOFieldProxyCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class HOMOFieldProxyCV:
    """
    Use HOMO centers as an electronic proxy near the transfer region.

    Returns two features evaluated at the transferring proton H*:
        - rho_like        = sum 1 / r^p           (density-like proxy)
        - E_parallel_like = sum ((r_H* - r_W)·u) / |r_H* - r_W|^3,
                            where u is the O_d -> O_a axis unit vector
                            (field-like projection)

    Expects:
        inputs.homo_centers : (M,3) HOMO/Wannier-like centers
        inputs.coords       : (N,3)
        inputs.reaction     : ReactionCenter-like with O_d, O_a, Hs
        inputs.box          : float or None

    Parameters:
        p : exponent in 1/r^p (default: 2.0)
    """
    name: str = "homo_field_proxy"
    p: float = 2.0
    labels: Tuple[str, ...] = ("rho_like", "E_parallel_like")

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        centers = getattr(inputs, "homo_centers", None)
        if rc is None or centers is None or len(centers) == 0:
            return np.array([np.nan, np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)

        O_d = int(rc.O_d)
        O_a = int(rc.O_a)
        Hs = int(getattr(rc, "Hs", -1))
        if Hs < 0:
            return np.array([np.nan, np.nan], dtype=float)

        rH = coords[Hs]
        axis = _pbc_delta(coords[O_a] - coords[O_d], L)
        norm = float(np.linalg.norm(axis))
        if norm == 0.0:
            return np.array([np.nan, np.nan], dtype=float)
        u = axis / norm

        rho_like = 0.0
        Epar_like = 0.0

        for w in centers:
            dr = _pbc_delta(rH - w, L)
            r = float(np.linalg.norm(dr))
            if r <= 1e-8:
                continue
            rho_like += 1.0 / (r ** self.p)
            Epar_like += float(np.dot(dr, u)) / (r ** 3)

        return np.array([rho_like, Epar_like], dtype=float)

# -------------------------------------------------------------------------
# 4) EParallelCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class EParallelCV:
    name: str = "E_parallel"
    use_midpoint_if_no_H: bool = True

    labels: tuple[str, ...] = field(default=("E_parallel",), init=False)

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        charges: Optional[np.ndarray] = getattr(inputs, "mulliken_charges", None)
        L = getattr(inputs, "box", None)
        rc = getattr(inputs, "reaction", None)

        # Må ha ladninger og reaction center
        if charges is None or rc is None:
            return np.array([np.nan], dtype=float)

        # Sikre 1D
        charges = np.asarray(charges).ravel()

        # *** NYTT: sanity-check på shape ***
        N = coords.shape[0]
        if charges.shape[0] != N:
            # Debug-print en gang per kjøring (eller log)
            # (Du kan evt. bruke logging i stedet for print)
            print(
                f"[EParallelCV] Shape mismatch: coords has {N} atoms, "
                f"mulliken_charges has {charges.shape[0]} entries. "
                "Returning NaN for this CV."
            )
            return np.array([np.nan], dtype=float)

        try:
            O_d = int(rc.O_d)
        except Exception:
            return np.array([np.nan], dtype=float)

        O_a = getattr(rc, "O_a", None)
        Hs = getattr(rc, "Hs", None)

        # Evalueringspunkt
        if Hs is not None and 0 <= int(Hs) < N:
            r_eval = coords[int(Hs)]
        elif self.use_midpoint_if_no_H and (O_a is not None):
            r_eval = 0.5 * (coords[O_d] + coords[int(O_a)])
        else:
            r_eval = coords[O_d]

        # Reaksjonsakse
        if O_a is not None:
            axis = _unit(_pbc_delta(coords[int(O_a)] - coords[O_d], L))
        elif Hs is not None and 0 <= int(Hs) < N:
            axis = _unit(_pbc_delta(coords[int(Hs)] - coords[O_d], L))
        else:
            return np.array([np.nan], dtype=float)

        # Coulombfelt
        r_vec = _pbc_delta(coords - r_eval, L)  # (N,3)
        r2 = np.einsum("ij,ij->i", r_vec, r_vec)  # (N,)
        mask = r2 > 1e-8
        r_vec = r_vec[mask]
        r2 = r2[mask]
        q = charges[mask]

        inv_r3 = 1.0 / (r2 * np.sqrt(r2) + 1e-20)
        E = (q[:, None] * r_vec) * inv_r3[:, None]
        E_tot = np.sum(E, axis=0)

        E_par = float(np.dot(E_tot, axis))
        return np.array([E_par], dtype=float)


from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np

@dataclass(slots=True)
class EParallelMultiAxisCV:
    """
    Elektrisk felt projisert langs flere relevante akser:

      1) O_d → O_a           (E_OdOa)
      2) O_d → nærmeste O ≠ O_a  (E_Od_NN)
      3) O_a → nærmeste O ≠ O_d  (E_Oa_NN)

    Feltet evalueres ved:
      - H* hvis tilgjengelig og indeksen er gyldig
      - ellers midtpunktet mellom oksygenparet for den aktuelle aksen.

    Alle tre verdiene kan bli NaN hvis geometrien mangler
    (ingen O_a, ingen naboer, ingen ladninger, etc.).
    """
    name: str = "E_parallel_multi"
    use_midpoint_if_no_H: bool = True

    labels: Tuple[str, ...] = field(
        default=("E_OdOa", "E_Od_NN", "E_Oa_NN"), init=False
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        charges: Optional[np.ndarray] = getattr(inputs, "mulliken_charges", None)
        L: Optional[float] = getattr(inputs, "box", None)
        rc = getattr(inputs, "reaction", None)
        neigh = getattr(inputs, "neighborhood", None)
        wtrip = getattr(inputs, "water_triplets", None)

        out = np.full((3,), np.nan, dtype=float)

        if charges is None or rc is None:
            return out

        try:
            O_d = int(rc.O_d)
            O_a = int(getattr(rc, "O_a", -1))
        except Exception:
            return out

        N = coords.shape[0]
        if not (0 <= O_d < N):
            return out

        Hs = getattr(rc, "Hs", None)
        H_idx = int(Hs) if Hs is not None and 0 <= int(Hs) < N else -1

        # --- liten hjelper for å regne E·axis ---
        def E_parallel_at(r_eval: np.ndarray, axis_vec: np.ndarray) -> float:
            axis = _unit(_pbc_delta(axis_vec, L))
            r_vec = _pbc_delta(coords - r_eval, L)  # (N,3)
            r2 = np.einsum("ij,ij->i", r_vec, r_vec)
            mask = r2 > 1e-8
            if not np.any(mask):
                return np.nan
            r_vec_m = r_vec[mask]
            r2_m = r2[mask]
            q = charges[mask]
            inv_r3 = 1.0 / (r2_m * np.sqrt(r2_m) + 1e-20)
            E = (q[:, None] * r_vec_m) * inv_r3[:, None]
            E_tot = np.sum(E, axis=0)
            return float(np.dot(E_tot, axis))

        # --- finn nærmeste naboer til O_d og O_a (ekskluder hverandre) ---
        def nearest_O_excluding(center: int, exclude: int) -> Optional[int]:
            cand_idx = None

            # 1) bruk neighborhood hvis mulig (for O_d)
            if neigh is not None and int(getattr(neigh, "center_O", -1)) == center:
                O_idx = np.asarray(getattr(neigh, "O_indices", []), dtype=int)
                d_OO = np.asarray(getattr(neigh, "d_OO", []), dtype=float)
                if O_idx.size > 0 and O_idx.size == d_OO.size:
                    mask = (O_idx != center) & (O_idx != exclude)
                    if np.any(mask):
                        jj = np.argmin(d_OO[mask])
                        return int(O_idx[mask][jj])

            # 2) fallback: scan over alle vannoksigener
            if wtrip is not None:
                O_all = np.asarray(wtrip[:, 1], dtype=int)
                mask = (O_all != center) & (O_all != exclude)
                if np.any(mask):
                    cand = O_all[mask]
                    vecs = _pbc_delta(coords[cand] - coords[center], L)
                    dists = np.linalg.norm(vecs, axis=1)
                    jj = np.argmin(dists)
                    cand_idx = int(cand[jj])

            return cand_idx

        # --- 1) E langs O_d → O_a ---
        if 0 <= O_a < N:
            axis_vec = coords[O_a] - coords[O_d]
            if H_idx >= 0:
                r_eval = coords[H_idx]
            elif self.use_midpoint_if_no_H:
                r_eval = 0.5 * (coords[O_d] + coords[O_a])
            else:
                r_eval = coords[O_d]
            out[0] = E_parallel_at(r_eval, axis_vec)

        # --- 2) E langs O_d → nærmeste O != O_a ---
        nn_d = nearest_O_excluding(O_d, O_a)
        if nn_d is not None and 0 <= nn_d < N:
            axis_vec = coords[nn_d] - coords[O_d]
            if H_idx >= 0:
                r_eval = coords[H_idx]
            else:
                r_eval = 0.5 * (coords[O_d] + coords[nn_d])
            out[1] = E_parallel_at(r_eval, axis_vec)

        # --- 3) E langs O_a → nærmeste O != O_d ---
        if 0 <= O_a < N:
            nn_a = nearest_O_excluding(O_a, O_d)
            if nn_a is not None and 0 <= nn_a < N:
                axis_vec = coords[nn_a] - coords[O_a]
                if H_idx >= 0:
                    r_eval = coords[H_idx]
                else:
                    r_eval = 0.5 * (coords[O_a] + coords[nn_a])
                out[2] = E_parallel_at(r_eval, axis_vec)

        return out
