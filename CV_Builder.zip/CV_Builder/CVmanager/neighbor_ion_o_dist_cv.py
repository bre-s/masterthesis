# CVmanager/neighbor_ion_o_dist_cv.py
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from typing import Iterable, Tuple

def _mic_delta(a: np.ndarray, b: np.ndarray, box: float | None) -> np.ndarray:
    d = b - a
    if box is not None and box > 0:
        d -= np.rint(d / box) * box
    return d

def _mic_dist(a: np.ndarray, b: np.ndarray, box: float | None) -> float:
    return float(np.linalg.norm(_mic_delta(a, b, box)))

def _guess_oxygens_from_names(names_ref: Iterable[str]) -> np.ndarray:
    # Accept common styles: "O", "O1", "OW", "Oxygen", "O_xx" etc.
    O_idx = []
    for i, name in enumerate(names_ref):
        n = str(name).strip()
        if not n:
            continue
        head = n.split()[0]  # tolerate things like "O  " or "O  (water)"
        head = head.replace('-', '').replace('_', '')
        head = head.upper()
        if head.startswith('O'):  # cheap but robust for most trajectories
            O_idx.append(i)
    return np.asarray(O_idx, dtype=int)

@dataclass(slots=True)
class NeighborIonODistCV:
    """
    Ranked distances from the *ion* (assumed last atom per frame) to the K nearest oxygen atoms.

    Columns: IonO1, IonO2, ... IonOK   (ranked by increasing distance)

    Exposes per-row metadata for the HDF5 writer:
      - last_rank_map: the oxygen invariant indices in the chosen rank order (int)
      - last_rank_labels: human labels "O<idx>" in the same order (str)
    """
    name: str = "neighbor_IonO_ranked"
    K: int = 12

    # Built in __post_init__
    labels: Tuple[str, ...] = field(default_factory=tuple, init=False)

    # Writer scratch
    last_rank_map: np.ndarray | None = field(default=None, init=False)
    last_rank_labels: np.ndarray | None = field(default=None, init=False)

    def __post_init__(self):
        self.labels = tuple(f"IonO{r}" for r in range(1, self.K + 1))

    def _collect_oxygen_indices(self, inputs) -> np.ndarray:
        """
        Priority:
          1) inputs.names_ref if available
          2) inputs.neighborhood.O_pool (if you have such a field)
          3) inputs.reaction.water_triplets[:,1] unique (O per water)
        """
        # Prefer names_ref if present
        names = getattr(inputs, "names_ref", None)
        if names is not None:
            O_idx = _guess_oxygens_from_names(names)
            return O_idx.astype(int)

        # Try reaction water triplets (O column = 1)
        rxn = getattr(inputs, "reaction", None)
        if rxn is not None and hasattr(rxn, "water_triplets"):
            O_idx = np.unique(rxn.water_triplets[:, 1]).astype(int)
            return O_idx

        # Fallback: assume every 3 atoms is a water (O,H,H) except last (ion)
        # This is only a last resort and assumes your pure water packing.
        n_atoms = int(inputs.coords.shape[0])
        n_waters = (n_atoms - 1) // 3  # -1 for ion, integer division
        O_idx = np.arange(n_waters, dtype=int) * 3  # 0,3,6,...
        return O_idx

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords            # (N,3)
        box = getattr(inputs, "box", None)
        n_atoms = int(coords.shape[0])
        if n_atoms < 2:
            # Nothing to compute
            self.last_rank_map = np.empty((0,), dtype=int)
            self.last_rank_labels = np.empty((0,), dtype=object)
            return np.full((self.K,), np.nan, dtype=float)

        # ---- 1) Finn ion-indeks på en trygg måte ----
        raw_ion_index = getattr(inputs, "ion_index", n_atoms - 1)

        try:
            ion_index = int(raw_ion_index)
        except (TypeError, ValueError):
            # Klarte ikke å tolke som int → fall tilbake til siste atom
            ion_index = n_atoms - 1
            print(
                f"[neighbor_IonO] non-integer ion_index={raw_ion_index!r} "
                f"→ using last atom index {ion_index} "
                f"(frame={getattr(inputs, 'key', None)})"
            )

        if ion_index < 0 or ion_index >= n_atoms:
            # Ugyldig indeks → fall tilbake til siste atom
            fallback = n_atoms - 1
            print(
                f"[neighbor_IonO] invalid ion_index={ion_index} (n_atoms={n_atoms}) "
                f"→ using last atom index {fallback} "
                f"(frame={getattr(inputs, 'key', None)})"
            )
            ion_index = fallback

        r_ion = coords[ion_index]

        # ---- 2) Bygg oksygen-pool, og sanity-sjekk indeksene ----
        O_all = self._collect_oxygen_indices(inputs)
        O_all = np.asarray(O_all, dtype=int)

        # kast åpenbart dårlige oksygen-indekser
        valid_mask = (O_all >= 0) & (O_all < n_atoms) & (O_all != ion_index)
        if not np.all(valid_mask):
            bad = O_all[~valid_mask]
            print(
                f"[neighbor_IonO] filtered out {bad.size} invalid O indices "
                f"(min={bad.min() if bad.size else None}, "
                f"max={bad.max() if bad.size else None}) "
                f"for frame={getattr(inputs, 'key', None)}"
            )
        O_all = O_all[valid_mask]

        if O_all.size == 0:
            # Ingen gyldige oksygen → logg og returner NaN
            print(
                f"[neighbor_IonO] no valid oxygen indices for frame="
                f"{getattr(inputs, 'key', None)}; returning NaNs."
            )
            self.last_rank_map = np.empty((0,), dtype=int)
            self.last_rank_labels = np.empty((0,), dtype=object)
            return np.full((self.K,), np.nan, dtype=float)

        # ---- 3) Beregn distanser Ion–O for alle gyldige oksygen ----
        dists = np.empty((len(O_all),), dtype=float)
        for i, o in enumerate(O_all):
            dists[i] = _mic_dist(r_ion, coords[int(o)], box)

        # Rank by distance
        order = np.argsort(dists)  # nearest first
        O_ranked = O_all[order]
        d_ranked = dists[order]

        # Truncate/pad to K
        out = np.full((self.K,), np.nan, dtype=float)
        take = min(self.K, len(d_ranked))
        out[:take] = d_ranked[:take]

        # Per-row metadata for writing
        self.last_rank_map = O_ranked[:take].astype(int)
        self.last_rank_labels = np.array(
            [f"O{idx}" for idx in self.last_rank_map],
            dtype=object,
        )

        return out

"""
    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords            # (N,3)
        box = getattr(inputs, "box", None)
        n_atoms = int(coords.shape[0])
        if n_atoms < 2:
            # Nothing to compute
            self.last_rank_map = np.empty((0,), dtype=int)
            self.last_rank_labels = np.empty((0,), dtype=object)
            return np.full((self.K,), np.nan, dtype=float)

        # Determine ion index. Prefer an explicit field; else assume last atom.
        ion_index = getattr(inputs, "ion_index", n_atoms - 1)
        r_ion = coords[ion_index]

        # Build oxygen pool and make sure we exclude the ion if it appears there
        O_all = self._collect_oxygen_indices(inputs)
        O_all = O_all[O_all != ion_index]

        # Compute distances Ion—O for all oxygens
        dists = np.empty((len(O_all),), dtype=float)
        for i, o in enumerate(O_all):
            dists[i] = _mic_dist(r_ion, coords[int(o)], box)

        # Rank by distance
        order = np.argsort(dists)  # nearest first
        O_ranked = O_all[order]
        d_ranked = dists[order]

        # Truncate/pad to K
        out = np.full((self.K,), np.nan, dtype=float)
        take = min(self.K, len(d_ranked))
        out[:take] = d_ranked[:take]

        # Per-row metadata for writing
        self.last_rank_map = O_ranked[:take].astype(int)
        # Labels like "O12", matching invariant oxygen indices
        self.last_rank_labels = np.array([f"O{idx}" for idx in self.last_rank_map],
                                            dtype=object)

        return out
"""