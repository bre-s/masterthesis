from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict, List, Set
import numpy as np


# ------------------ små hjelpefunksjoner ------------------ #

def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _mic_dist(a: np.ndarray, b: np.ndarray, L: Optional[float]) -> float:
    return float(np.linalg.norm(_pbc_delta(b - a, L)))


def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


def _build_water_maps(water_triplets: np.ndarray) -> tuple[np.ndarray, Dict[int, Tuple[int, int]]]:
    """
    water_triplets: (nW,3) med rader [H1, O, H2] i invariant rekkefølge.
    Returnerer:
        O_all          : array av alle O-indekser
        H_pairs_by_O   : dict O_index -> (H1, H2)
    """
    O_all = water_triplets[:, 1].astype(int)
    H_pairs_by_O: Dict[int, Tuple[int, int]] = {
        int(O): (int(h1), int(h2)) for (h1, O, h2) in water_triplets
    }
    return O_all, H_pairs_by_O


def _hb_graph(
    coords: np.ndarray,
    O_all: np.ndarray,
    H_pairs_by_O: Dict[int, Tuple[int, int]],
    rcut: float,
    angle_cut_deg: float,
    L: Optional[float],
) -> Dict[int, set[int]]:
    """
    Bygger en urettet graf mellom oksygenatomer, hvor kant eksisterer
    hvis Oi-Oj er innenfor rcut og donor-vinkelkriteriet er oppfylt ved Oi.
    """
    cos_cut = float(np.cos(np.deg2rad(angle_cut_deg)))
    rcut2 = float(rcut ** 2)
    Opos = coords[O_all]  # (nO,3)
    nO = len(O_all)

    adj: Dict[int, set[int]] = {int(o): set() for o in O_all}

    for i in range(nO):
        Oi = int(O_all[i])
        d = Opos - Opos[i]
        if L is not None and L > 0:
            d = d - np.rint(d / L) * L
        r2 = np.einsum("ij,ij->i", d, d)
        cand = np.where((r2 <= rcut2) & (r2 > 0.0))[0]
        if cand.size == 0:
            continue

        H1, H2 = H_pairs_by_O[Oi]
        v1 = _unit(_pbc_delta(coords[H1] - coords[Oi], L))
        v2 = _unit(_pbc_delta(coords[H2] - coords[Oi], L))

        for j in cand:
            Oj = int(O_all[j])
            u = _unit(d[j])
            if (v1 @ u) >= cos_cut or (v2 @ u) >= cos_cut:
                adj[Oi].add(Oj)
                adj[Oj].add(Oi)

    return adj



def _best_path_with_nodes(
    center_O: Optional[int],
    N: int,
    adj: Optional[Dict[int, Set[int]]],
    coords: np.ndarray,
    L: Optional[float],
) -> Tuple[float, Optional[Tuple[int, ...]]]:
    """
    Shortest simple path of exactly N nodes starting at center_O.
    Returns (best_length, best_path) or (inf, None).
    Safeguarded for center_O=None or adj=None.
    """
    # Først: hvis center_O mangler eller adj er None → ingen vei
    if center_O is None or adj is None:
        return np.inf, None

    # Nå vet både vi og typechecker at adj != None
    graph: Dict[int, Set[int]] = adj

    if center_O not in graph:
        return np.inf, None

    start: int = int(center_O)

    best = np.inf
    best_path: Optional[Tuple[int, ...]] = None

    def dfs(path: List[int], seen: set[int]) -> None:
        nonlocal best, best_path
        if len(path) == N:
            s = 0.0
            for a, b in zip(path[:-1], path[1:]):
                s += _mic_dist(coords[a], coords[b], L)
            if s < best:
                best = s
                best_path = tuple(path)
            return

        last = path[-1]
        # Bruk graph, ikke adj → graph er garantert non-None
        for nxt in graph.get(last, ()):
            if nxt in seen:
                continue
            seen.add(nxt)
            path.append(nxt)
            dfs(path, seen)
            path.pop()
            seen.remove(nxt)

    dfs([start], {start})
    return best, best_path


# ------------------ Wire-deriverte CVer ------------------ #

@dataclass(slots=True)
class _BaseWireCV:
    """
    Felles base for wire-CVer: bygger hydrogenbindnings-graf og finner beste path.
    """
    rcut: float = 3.5
    angle_cut_deg: float = 30.0
    center: str = "donor"  # "donor" eller "acceptor"
    path_node_lengths: Tuple[int, ...] = (3, 4, 5, 6)

    def _prepare_graph(self, inputs):
        coords: np.ndarray = inputs.coords
        L = getattr(inputs, "box", None)
        water_triplets: np.ndarray = inputs.water_triplets

        O_all, H_pairs_by_O = _build_water_maps(water_triplets)
        adj = _hb_graph(coords, O_all, H_pairs_by_O, self.rcut, self.angle_cut_deg, L)

        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return None, None, None, None
        center_O = int(rc.O_d if self.center == "donor" else rc.O_a)
        return coords, L, adj, center_O

    def _get_paths(self, inputs) -> Dict[int, Optional[Tuple[int, ...]]]:
        coords, L, adj, center_O = self._prepare_graph(inputs)
        if coords is None:
            return {N: None for N in self.path_node_lengths}

        paths: Dict[int, Optional[Tuple[int, ...]]] = {}
        for N in self.path_node_lengths:
            if N < 2:
                paths[N] = None
                continue
            _, best_path = _best_path_with_nodes(center_O, N, adj, coords, L)
            paths[N] = best_path
        return paths


@dataclass(slots=True)
class WireCompressionCV(_BaseWireCV):
    """
    Wire-kompresjon W_N = sum O–O langs beste N-node path.

    Output: [W_L{N1}, W_L{N2}, ...]
    """
    name: str = "wire_compression"
    labels: Tuple[str, ...] = field(init=False)

    def __post_init__(self):
        cols = [f"W_L{N}" for N in self.path_node_lengths]
        object.__setattr__(self, "labels", tuple(cols))

    def compute(self, inputs) -> np.ndarray:
        coords, L, adj, center_O = self._prepare_graph(inputs)
        if coords is None:
            return np.full((len(self.path_node_lengths),), np.nan, dtype=float)

        vals: List[float] = []
        for N in self.path_node_lengths:
            if N < 2:
                vals.append(np.nan)
                continue
            best_len, best_path = _best_path_with_nodes(center_O, N, adj, coords, L)
            vals.append(float(best_len) if best_path is not None else np.nan)
        return np.asarray(vals, dtype=float)


@dataclass(slots=True)
class WireFirstOOCV(_BaseWireCV):
    """
    Første O–O-avstand i beste N-node path, dvs. mellom node 0 og 1.

    Output: [R_OO_first_L{N1}, R_OO_first_L{N2}, ...]
    """
    name: str = "wire_first_OO"
    labels: Tuple[str, ...] = field(init=False)

    def __post_init__(self):
        cols = [f"R_OO_first_L{N}" for N in self.path_node_lengths]
        object.__setattr__(self, "labels", tuple(cols))

    def compute(self, inputs) -> np.ndarray:
        coords, L, adj, center_O = self._prepare_graph(inputs)
        if coords is None:
            return np.full((len(self.path_node_lengths),), np.nan, dtype=float)

        vals: List[float] = []
        for N in self.path_node_lengths:
            if N < 2:
                vals.append(np.nan)
                continue
            _, best_path = _best_path_with_nodes(center_O, N, adj, coords, L)
            if best_path is None:
                vals.append(np.nan)
            else:
                R01 = _mic_dist(coords[best_path[0]], coords[best_path[1]], L)
                vals.append(float(R01))
        return np.asarray(vals, dtype=float)


@dataclass(slots=True)
class WireSigmaOOCV(_BaseWireCV):
    """
    Standardavvik i O–O-avstander langs beste N-node path.

    Output: [sigma_OO_L{N1}, sigma_OO_L{N2}, ...]
    """
    name: str = "wire_sigma_OO"
    labels: Tuple[str, ...] = field(init=False)

    def __post_init__(self):
        cols = [f"sigma_OO_L{N}" for N in self.path_node_lengths]
        object.__setattr__(self, "labels", tuple(cols))

    def compute(self, inputs) -> np.ndarray:
        coords, L, adj, center_O = self._prepare_graph(inputs)
        if coords is None:
            return np.full((len(self.path_node_lengths),), np.nan, dtype=float)

        out: List[float] = []
        for N in self.path_node_lengths:
            if N < 2:
                out.append(np.nan)
                continue
            _, best_path = _best_path_with_nodes(center_O, N, adj, coords, L)
            if best_path is None:
                out.append(np.nan)
            else:
                dists = []
                for a, b in zip(best_path[:-1], best_path[1:]):
                    dists.append(_mic_dist(coords[a], coords[b], L))
                out.append(float(np.std(dists)))
        return np.asarray(out, dtype=float)


@dataclass(slots=True)
class WireLinearityCVCos(_BaseWireCV):
    """
    Lineæritet langs wieren: cos(theta) for O–O–O-tripler langs path.

    reduce:
        "mean" -> gjennomsnittlig cos
        "min"  -> minimum (mest bøyde segment)

    Output: [q_cos_L{N1}, q_cos_L{N2}, ...]
    """
    name: str = "wire_linearity_cos"
    reduce: str = "mean"  # "mean" eller "min"
    labels: Tuple[str, ...] = field(init=False)

    def __post_init__(self):
        cols = [f"q_cos_L{N}" for N in self.path_node_lengths]
        object.__setattr__(self, "labels", tuple(cols))

    def compute(self, inputs) -> np.ndarray:
        coords, L, adj, center_O = self._prepare_graph(inputs)
        if coords is None:
            return np.full((len(self.path_node_lengths),), np.nan, dtype=float)

        out: List[float] = []
        for N in self.path_node_lengths:
            if N < 3:
                out.append(np.nan)
                continue
            _, best_path = _best_path_with_nodes(center_O, N, adj, coords, L)
            if best_path is None:
                out.append(np.nan)
                continue

            cos_vals = []
            for i in range(1, len(best_path) - 1):
                a = best_path[i - 1]
                b = best_path[i]
                c = best_path[i + 1]
                v1 = _unit(_pbc_delta(coords[a] - coords[b], L))
                v2 = _unit(_pbc_delta(coords[c] - coords[b], L))
                cos_vals.append(float(v1 @ v2))

            if not cos_vals:
                out.append(np.nan)
            else:
                if self.reduce == "min":
                    out.append(float(np.min(cos_vals)))
                else:
                    out.append(float(np.mean(cos_vals)))
        return np.asarray(out, dtype=float)


# ------------------ MultiProtonCoordsCV ------------------ #

@dataclass(slots=True)
class MultiProtonCoordsCV(_BaseWireCV):
    """
    Multi-proton-lik koordinat langs en H-bond wire.

    For beste N-node path (O_0,...,O_{N-1}):
        for hvert par (O_i, O_{i+1}):
            - finn et "bridging H" som minimerer (r(O_i,H) + r(O_{i+1},H))
            blant alle H (fra water_triplets)
            - definer δ_i = r(O_i,H) - r(O_{i+1},H)
            - definer R_i = r(O_i,O_{i+1})

    Returnerer for hver N:
        Σδ_LN = sum_i δ_i
        ΣR_OO_LN = sum_i R_i  (dette er lik W_N, men vi tar den med eksplisitt)

    Output:
        [Sigma_delta_LN1, Sigma_R_OO_LN1, Sigma_delta_LN2, Sigma_R_OO_LN2, ...]
    """
    name: str = "multi_proton_coords"
    labels: Tuple[str, ...] = field(init=False)

    def __post_init__(self):
        cols: List[str] = []
        for N in self.path_node_lengths:
            cols.append(f"Sigma_delta_L{N}")
            cols.append(f"Sigma_R_OO_L{N}")
        object.__setattr__(self, "labels", tuple(cols))

    def compute(self, inputs) -> np.ndarray:
        coords, L, adj, center_O = self._prepare_graph(inputs)
        if coords is None:
            return np.full((2 * len(self.path_node_lengths),), np.nan, dtype=float)

        water_triplets: np.ndarray = inputs.water_triplets
        H_all = water_triplets[:, [0, 2]].astype(int).ravel()  # alle H i systemet

        out_vals: List[float] = []

        for N in self.path_node_lengths:
            if N < 2:
                out_vals.extend([np.nan, np.nan])
                continue

            _, best_path = _best_path_with_nodes(center_O, N, adj, coords, L)
            if best_path is None:
                out_vals.extend([np.nan, np.nan])
                continue

            sig_delta = 0.0
            sig_R = 0.0

            for a, b in zip(best_path[:-1], best_path[1:]):
                # bridging H: minimer r(Oa,H) + r(Ob,H)
                ra = coords[a]
                rb = coords[b]

                best_cost = np.inf
                best_r_a = np.nan
                best_r_b = np.nan

                for h in H_all:
                    rh = coords[h]
                    d_a = _mic_dist(ra, rh, L)
                    d_b = _mic_dist(rb, rh, L)
                    cost = d_a + d_b
                    if cost < best_cost:
                        best_cost = cost
                        best_r_a = d_a
                        best_r_b = d_b

                if not np.isfinite(best_r_a) or not np.isfinite(best_r_b):
                    continue

                delta = best_r_a - best_r_b
                R_ab = _mic_dist(ra, rb, L)

                sig_delta += delta
                sig_R += R_ab

            out_vals.append(float(sig_delta))
            out_vals.append(float(sig_R))

        return np.asarray(out_vals, dtype=float)
