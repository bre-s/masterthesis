"""
Disse bygger intern state per traj_path. Med nåværende SimulationRunner (som kun tar ett frame per gridpoint) 
vil du ofte få NaN på derivater, helt til du faktisk begynner å mate inn sekvenser av frames langs samme trajektorie. 
Men CVer er klare og “plug-and-play” når du først gjør det.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _mic_dist(a: np.ndarray, b: np.ndarray, L: Optional[float]) -> float:
    return float(np.linalg.norm(_pbc_delta(b - a, L)))

def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


# ----------------------------------------------------------------------
# 1) ROODotCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class ROODotCV:
    """
    Tidsderivert av R_OO = |O_d - O_a|.

    For samme traj_path:

        Rdot(t) = (R(t) - R(t-dt)) / dt_fs

    Hvis ingen tidligere frame for samme traj_path: returner NaN.

    Expects:
        inputs.reaction   : RC med O_d, O_a
        inputs.coords     : (N,3)
        inputs.box        : float eller None
        inputs.traj_path  : Path (identifiserer trajektorie)

    Output:
        [Rdot]
    """
    name: str = "ROO_dot"
    dt_fs: float = 1.0
    labels: Tuple[str, ...] = ("ROO_dot",)

    _last_R: Dict[str, float] = field(default_factory=dict, init=False)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        O_d = int(rc.O_d)
        O_a = int(rc.O_a)

        R_curr = _mic_dist(coords[O_d], coords[O_a], L)
        path_id = str(getattr(inputs, "traj_path", "unknown"))

        if path_id not in self._last_R:
            self._last_R[path_id] = R_curr
            return np.array([np.nan], dtype=float)

        R_prev = self._last_R[path_id]
        self._last_R[path_id] = R_curr
        Rdot = (R_curr - R_prev) / self.dt_fs
        return np.array([float(Rdot)], dtype=float)


# ----------------------------------------------------------------------
# 2) DeltaDotCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class DeltaDotCV:
    """
    Tidsderivert av Zundel-koordinaten δ = R_OdH - R_OaH for H*.

    For samme traj_path:

        δdot = (δ(t) - δ(t-dt)) / dt_fs

    Output:
        [delta_dot]
    """
    name: str = "delta_dot"
    dt_fs: float = 1.0
    labels: Tuple[str, ...] = ("delta_dot",)

    _last_delta: Dict[str, float] = field(default_factory=dict, init=False)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        O_d = int(rc.O_d)
        O_a = int(rc.O_a)
        Hs = int(getattr(rc, "Hs", -1))

        if Hs < 0:
            return np.array([np.nan], dtype=float)

        R_OdH = _mic_dist(coords[O_d], coords[Hs], L)
        R_OaH = _mic_dist(coords[O_a], coords[Hs], L)
        delta = R_OdH - R_OaH

        path_id = str(getattr(inputs, "traj_path", "unknown"))
        if path_id not in self._last_delta:
            self._last_delta[path_id] = delta
            return np.array([np.nan], dtype=float)

        delta_prev = self._last_delta[path_id]
        self._last_delta[path_id] = delta
        d_dot = (delta - delta_prev) / self.dt_fs
        return np.array([float(d_dot)], dtype=float)


# ----------------------------------------------------------------------
# 3) HBBondLifetimeCV
# ----------------------------------------------------------------------

def _find_main_acceptor(
    coords: np.ndarray,
    center_O: int,
    h1: int,
    h2: int,
    wtrip: np.ndarray,
    R_OO_max: float,
    angle_min_deg: float,
    L: Optional[float],
) -> Optional[int]:
    """
    Returner indeks (O_index) til "hoved"-akseptoren (nærmeste O som danner H-binding),
    eller None hvis ingen.
    """
    cos_cut = float(np.cos(np.deg2rad(angle_min_deg)))
    rcut2 = float(R_OO_max ** 2)

    O_all = wtrip[:, 1].astype(int)
    Opos0 = coords[center_O]

    d = coords[O_all] - Opos0
    if L is not None and L > 0:
        d = d - np.rint(d / L) * L

    r2 = np.einsum("ij,ij->i", d, d)
    mask = (r2 <= rcut2) & (r2 > 0.0)
    if not np.any(mask):
        return None

    v1 = _unit(_pbc_delta(coords[h1] - Opos0, L))
    v2 = _unit(_pbc_delta(coords[h2] - Opos0, L))

    best_O = None
    best_r2 = np.inf
    for idx, ok in enumerate(mask):
        if not ok:
            continue
        Oj = O_all[idx]
        u = _unit(d[idx])
        if (u @ v1) < cos_cut and (u @ v2) < cos_cut:
            continue
        if r2[idx] < best_r2:
            best_r2 = r2[idx]
            best_O = int(Oj)
    return best_O

@dataclass
class _HBLifeState:
    last_exists: bool = False
    last_partner: Optional[int] = None
    lifetime: float = 0.0

@dataclass(slots=True)
class HBBondLifetimeCV:
    """
    Estimert "lifettime" (i fs) til hoved-H-bindingen fra center-O (O_d) til nærmeste acceptor.

    Per traj_path lagres:
        - forrige partner (O_index)
        - forrige "exists"-status
        - akkumulert lifetime

    Hvis bindingen finnes og også fantes forrige frame: lifetime += dt_fs
    Hvis bindingen finnes, men ikke fantes før: lifetime = dt_fs
    Hvis bindingen ikke finnes: lifetime = 0

    Output:
        [HB_lifetime_fs]
    """
    name: str = "hb_bond_lifetime"
    dt_fs: float = 1.0
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    labels: Tuple[str, ...] = ("HB_lifetime_fs",)

    _state: Dict[str, _HBLifeState] = field(default_factory=dict, init=False)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d)

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)
        h1, o0, h2 = map(int, wtrip[row[0]])

        partner = _find_main_acceptor(
            coords, center_O, h1, h2, wtrip,
            self.R_OO_max, self.angle_min_deg, L
        )
        exists = partner is not None

        path_id = str(getattr(inputs, "traj_path", "unknown"))
        st = self._state.get(path_id)
        if st is None:
            st = _HBLifeState()

        if exists and partner is not None:
            if st.last_exists and st.last_partner == partner:
                st.lifetime += self.dt_fs
            else:
                st.lifetime = self.dt_fs
            st.last_exists = True
            st.last_partner = partner
        else:
            st.last_exists = False
            st.last_partner = None
            st.lifetime = 0.0

        self._state[path_id] = st
        return np.array([st.lifetime], dtype=float)


# ----------------------------------------------------------------------
# 4) HBSwitchFrequencyCV
# ----------------------------------------------------------------------
@dataclass
class _HBSwitchState:
    last_partner: Optional[int] = None
    switch_count: int = 0
    elapsed: float = 0.0


@dataclass(slots=True)
class HBSwitchFrequencyCV:
    """
    Hyppighet av H-bond-partner-bytter for center-O (O_d).

    For hver traj_path:
        - identifiser "hoved"-akseptor
        - hvis partner bytter (forrige partner != ny), øk switch_count
        - øk elapsed_time med dt_fs

    Frekvens = switch_count / elapsed_time (0 hvis elapsed_time==0).

    Output:
        [switch_frequency_per_fs]
    """
    name: str = "hb_switch_frequency"
    dt_fs: float = 1.0
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    labels: Tuple[str, ...] = ("switch_freq_per_fs",)

    _state: Dict[str, _HBSwitchState] = field(default_factory=dict, init=False)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d)

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)
        h1, o0, h2 = map(int, wtrip[row[0]])

        partner = _find_main_acceptor(
            coords, center_O, h1, h2, wtrip,
            self.R_OO_max, self.angle_min_deg, L
        )

        path_id = str(getattr(inputs, "traj_path", "unknown"))
        st = self._state.get(path_id)
        if st is None:
            st = _HBSwitchState()

        if st.last_partner is not None and partner is not None and partner != st.last_partner:
            st.switch_count += 1

        st.last_partner = partner
        st.elapsed += self.dt_fs
        self._state[path_id] = st

        if st.elapsed <= 0.0:
            return np.array([0.0], dtype=float)
        freq = st.switch_count / st.elapsed
        return np.array([freq], dtype=float)

