from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, Dict
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


def _collect_hb_acceptors(
    coords: np.ndarray,
    center_O: int,
    H1: int,
    H2: int,
    O_all: np.ndarray,
    R_OO_max: float,
    angle_min_deg: float,
    L: Optional[float],
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Finn alle H-bond akseptorer for center_O (som donor), og returner:
        - dist: O–O distanser (MIC)
        - angles_deg: O–H···O vinkler i grader (maks av H1/H2-bidrag)
    """

    # 1) Finn O-akseptor kandidater innenfor R_OO_max
    Opos0 = coords[center_O]
    d = coords[O_all] - Opos0
    if L is not None and L > 0:
        d = d - np.rint(d / L) * L

    r2 = np.einsum("ij,ij->i", d, d)
    cand_idx = np.where((r2 <= R_OO_max**2) & (r2 > 0.0))[0]
    if cand_idx.size == 0:
        return np.zeros((0,), dtype=float), np.zeros((0,), dtype=float)

    # 2) Precompute H→O_d vektorer (for begge H)
    vH1_Od = _unit(_pbc_delta(coords[center_O] - coords[H1], L))  # H1 -> O_d
    vH2_Od = _unit(_pbc_delta(coords[center_O] - coords[H2], L))  # H2 -> O_d

    dist_list: list[float] = []
    angle_list: list[float] = []

    for idx in cand_idx:
        Oj = int(O_all[idx])

        # H1: H1 -> O_j
        vH1_Oj = _unit(_pbc_delta(coords[Oj] - coords[H1], L))  # H1 -> O_j
        cos1 = float(np.clip(np.dot(vH1_Od, vH1_Oj), -1.0, 1.0))
        angle1 = float(np.rad2deg(np.arccos(cos1)))  # ∠O_d–H1–O_j

        # H2: H2 -> O_j
        vH2_Oj = _unit(_pbc_delta(coords[Oj] - coords[H2], L))  # H2 -> O_j
        cos2 = float(np.clip(np.dot(vH2_Od, vH2_Oj), -1.0, 1.0))
        angle2 = float(np.rad2deg(np.arccos(cos2)))  # ∠O_d–H2–O_j

        angle_max = max(angle1, angle2)

        # 3) H-bond-kriterie: O–H···O-vinkel >= angle_min_deg
        if angle_max >= angle_min_deg:
            dist_list.append(float(np.sqrt(r2[idx])))
            angle_list.append(angle_max)

    if not dist_list:
        return np.zeros((0,), dtype=float), np.zeros((0,), dtype=float)

    dist = np.asarray(dist_list, dtype=float)
    angles = np.asarray(angle_list, dtype=float)
    return dist, angles



# ----------------------------------------------------------------------
# 1) HBAngleMeanCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class HBAngleMeanCV:
    """
    Gjennomsnittlig O–H···O-vinkel (i grader) for H-bindinger fra center-O som donor.

    Center oxygen:
        if use_donor_O=True  -> rc.O_d
        else                 -> rc.O_a

    Output:
        [angle_mean_deg]
    """
    name: str = "hb_angle_mean"
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("hb_angle_mean_deg",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        wtrip = inputs.water_triplets

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        dist, angles = _collect_hb_acceptors(
            inputs.coords, center_O, h1, h2, O_all,
            self.R_OO_max, self.angle_min_deg,
            getattr(inputs, "box", None),
        )
        if angles.size == 0:
            return np.array([np.nan], dtype=float)

        return np.array([float(np.mean(angles))], dtype=float)


# ----------------------------------------------------------------------
# 2) HBTotalCountCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class HBTotalCountCV:
    """
    Totalt antall H-bindinger rundt center-O, definert som:
        - aksepterte bindinger (center som donor)
        - donerte bindinger (center som akseptor)

    Vi teller begge typene slik:
        - som donor: via _collect_hb_acceptors
        - som akseptor: vi looper over alle andre vann og sjekker om center
        ligger i donor-kjeglen til disse.

    Output:
        [n_hb_total]
    """
    name: str = "hb_total_count"
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("n_hb_total",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        # center som donor
        dist, _ = _collect_hb_acceptors(
            coords, center_O, h1, h2, O_all,
            self.R_OO_max, self.angle_min_deg,
            L,
        )
        n_don = int(dist.size)

        # center som akseptor
        cos_cut = float(np.cos(np.deg2rad(self.angle_min_deg)))
        rcut2 = float(self.R_OO_max ** 2)

        n_acc = 0
        for (h1p, op, h2p) in wtrip.astype(int):
            if op == center_O:
                continue
            d = _pbc_delta(coords[center_O] - coords[op], L)
            r2 = float(d @ d)
            if r2 <= 0.0 or r2 > rcut2:
                continue
            u = _unit(d)
            v1 = _unit(_pbc_delta(coords[h1p] - coords[op], L))
            v2 = _unit(_pbc_delta(coords[h2p] - coords[op], L))
            if (u @ v1) >= cos_cut or (u @ v2) >= cos_cut:
                n_acc += 1

        return np.array([float(n_don + n_acc)], dtype=float)


# ----------------------------------------------------------------------
# 3) HBDonAcceptRatioCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class HBDonAcceptRatioCV:
    """
    Forholdet n_don / n_acc for H-bindinger ved center-O.

    Definisjon:
        n_don = antall bindinger hvor center er donor
        n_acc = antall bindinger hvor center er akseptor
        ratio = n_don / n_acc (NaN om n_acc==0)

    Output:
        [don_accept_ratio]
    """
    name: str = "hb_don_accept_ratio"
    R_OO_max: float = 3.5
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("don_accept_ratio",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets
        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        # center som donor
        dist, _ = _collect_hb_acceptors(
            coords, center_O, h1, h2, O_all,
            self.R_OO_max, self.angle_min_deg,
            L,
        )
        n_don = int(dist.size)

        # center som akseptor
        cos_cut = float(np.cos(np.deg2rad(self.angle_min_deg)))
        rcut2 = float(self.R_OO_max ** 2)

        n_acc = 0
        for (h1p, op, h2p) in wtrip.astype(int):
            if op == center_O:
                continue
            d = _pbc_delta(coords[center_O] - coords[op], L)
            r2 = float(d @ d)
            if r2 <= 0.0 or r2 > rcut2:
                continue
            u = _unit(d)
            v1 = _unit(_pbc_delta(coords[h1p] - coords[op], L))
            v2 = _unit(_pbc_delta(coords[h2p] - coords[op], L))
            if (u @ v1) >= cos_cut or (u @ v2) >= cos_cut:
                n_acc += 1

        if n_acc == 0:
            return np.array([np.nan], dtype=float)
        return np.array([float(n_don) / float(n_acc)], dtype=float)


# ----------------------------------------------------------------------
# 4) HBStrengthCV
# ----------------------------------------------------------------------

@dataclass(slots=True)
class HBStrengthCV:
    """
    Effektiv H-bond "styrke" rundt center-O som donor:

        HB_strength = Σ exp[-(R_OO - R0)/sigma]  over alle akseptorer

    Parameter:
        R_OO_max   : cutoff for å telle H-bindinger (Å)
        R0         : "referanse"-lengde (typisk ~2.8 Å)
        sigma      : bredde (0.2–0.4 Å anbefalt)
        use_donor_O: velg O_d eller O_a som center

    Output:
        [HB_strength]
    """
    name: str = "hb_strength"
    R_OO_max: float = 3.5
    R0: float = 2.8
    sigma: float = 0.3
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("HB_strength",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        wtrip = inputs.water_triplets

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        dist, _ = _collect_hb_acceptors(
            inputs.coords,
            center_O,
            h1,
            h2,
            O_all,
            self.R_OO_max,
            self.angle_min_deg,
            getattr(inputs, "box", None),
        )
        if dist.size == 0:
            return np.array([0.0], dtype=float)

        weights = np.exp(-(dist - self.R0) / self.sigma)
        return np.array([float(np.sum(weights))], dtype=float)
