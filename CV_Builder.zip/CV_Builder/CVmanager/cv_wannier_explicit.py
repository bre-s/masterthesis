from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np

def _mic_delta(a: np.ndarray, b: np.ndarray, box: float | None) -> np.ndarray:
    d = b - a
    if box is not None and box > 0:
        d -= np.rint(d / box) * box
    return d

def _mic_dist(a: np.ndarray, b: np.ndarray, box: float | None) -> float:
    return float(np.linalg.norm(_mic_delta(a, b, box)))

def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


def _select_centers_for_atom(
    centers: np.ndarray,
    atom_pos: np.ndarray,
    L: Optional[float],
    k: int = 2
) -> np.ndarray:
    """
    Pick k centers nearest a given atom (MIC).
    Used as lone-pair proxy.
    """
    d = centers - atom_pos
    if L is not None and L > 0:
        d = d - np.rint(d / L) * L
    r = np.linalg.norm(d, axis=1)
    idx = np.argsort(r)[:max(1, k)]
    return centers[idx]


# -------------------------------------------------------------------------
# 1) LpOrientationAtAcceptorCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class LpOrientationAtAcceptorCV:
    """
    Retningsfølsom “lone-pair”-orientering ved akseptor-oksigenet O_a,
    basert på Wannier- eller HOMO-sentre.

    Steg:
      - Finn O_a og dens to kovalente H (Ha, Hb) fra water_triplets (H1,O,H2).
      - Definér:
            H_long  = H med lengst O_a–H
            H_short = H med kortest O_a–H
      - Definér akser:
            e_axis  = enhetsvektor langs O_d → O_a
            e_long  = enhetsvektor langs O_a → H_long
            e_short = enhetsvektor langs O_a → H_short
      - Velg “lp-lignende” sentre C i en kule rundt O_a:
            R_min_lp <= |O_a–C| <= R_max_lp
        (bruker wannier_centers hvis tilgjengelig, ellers homo_centers)
      - For hvert slikt C:
            n = enhetsvektor O_a → C
            cos_axis  = n · e_axis
            cos_long  = n · e_long
            cos_short = n · e_short

    Output:
      [N_lp_like, mean_cos_axis, mean_cos_long, mean_cos_short]

    Hvis ingen sentre i lp-skallet:
      → [0.0, NaN, NaN, NaN]
    Hvis ingen wannier/homo-data: alle NaN.
    """

    name: str = "lp_orientation_at_acceptor"
    R_min_lp: float = 0.8   # Å – inner radius for “lp-lignende” region
    R_max_lp: float = 2.5   # Å – outer radius for “lp-lignende” region

    labels: Tuple[str, ...] = field(
        default=("N_lp_like", "lp_mean_cos_axis", "lp_mean_cos_long", "lp_mean_cos_short"),
        init=False,
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L: Optional[float] = getattr(inputs, "box", None)
        wtrip: np.ndarray = inputs.water_triplets
        rc = getattr(inputs, "reaction", None)

        if rc is None:
            return np.full((4,), np.nan, dtype=float)

        try:
            O_d = int(rc.O_d)
            O_a = int(rc.O_a)
        except Exception:
            return np.full((4,), np.nan, dtype=float)

        N_atoms = coords.shape[0]
        if not (0 <= O_d < N_atoms and 0 <= O_a < N_atoms):
            return np.full((4,), np.nan, dtype=float)

        # Finn H rundt O_a fra water_triplets (H1,O,H2)
        row = np.where(wtrip[:, 1] == O_a)[0]
        if len(row) == 0:
            return np.full((4,), np.nan, dtype=float)
        h1, o0, h2 = map(int, wtrip[row[0]])

        # Definér H_long / H_short via bondlengde O_a–H
        r1 = _mic_dist(coords[O_a], coords[h1], L)
        r2 = _mic_dist(coords[O_a], coords[h2], L)
        if r1 >= r2:
            H_long, H_short = h1, h2
        else:
            H_long, H_short = h2, h1

        # Akser
        e_axis = _unit(_pbc_delta(coords[O_a] - coords[O_d], L))     # O_d → O_a
        e_long = _unit(_pbc_delta(coords[H_long] - coords[O_a], L))  # O_a → H_long
        e_short = _unit(_pbc_delta(coords[H_short] - coords[O_a], L))# O_a → H_short

        # Elektronsentre: wannier_centers først, ellers homo_centers
        centers = getattr(inputs, "wannier_centers", None)
        if centers is None:
            centers = getattr(inputs, "homo_centers", None)
        if centers is None or centers.size == 0:
            return np.full((4,), np.nan, dtype=float)

        # Vektorer O_a → C
        vecs = _pbc_delta(centers - coords[O_a], L)
        r = np.linalg.norm(vecs, axis=1)

        mask = (r >= self.R_min_lp) & (r <= self.R_max_lp)
        if not np.any(mask):
            return np.array([0.0, np.nan, np.nan, np.nan], dtype=float)

        vecs_lp = vecs[mask]
        r_lp = r[mask]
        n_vecs = vecs_lp / (r_lp[:, None] + 1e-20)

        cos_axis = n_vecs @ e_axis
        cos_long = n_vecs @ e_long
        cos_short = n_vecs @ e_short

        N_lp_like = float(len(r_lp))
        mean_cos_axis = float(np.mean(cos_axis))
        mean_cos_long = float(np.mean(cos_long))
        mean_cos_short = float(np.mean(cos_short))

        return np.array(
            [N_lp_like, mean_cos_axis, mean_cos_long, mean_cos_short],
            dtype=float,
        )



# -------------------------------------------------------------------------
# 2) BondCenterPositionCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class BondCenterPositionCV:
    """
    Bond-center position along O_d–H* (s_OH).

    Uses centers (Wannier or HOMO) and finds the center nearest
    the O_d–H* line, then returns its normalized coordinate s in [0,1].

    Output:
        [s_OH]
    """
    name: str = "bond_center_position"
    labels: Tuple[str, ...] = ("s_OH",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        centers = getattr(inputs, "wannier_centers", None)
        if centers is None:
            centers = getattr(inputs, "homo_centers", None)
        if centers is None or len(centers) == 0:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)

        Od = int(rc.O_d)
        Hs = int(getattr(rc, "Hs", -1))
        if Hs < 0:
            return np.array([np.nan], dtype=float)

        rO = coords[Od]
        rH = coords[Hs]
        oh = _pbc_delta(rH - rO, L)
        n = float(np.linalg.norm(oh))
        if n == 0.0:
            return np.array([np.nan], dtype=float)

        u = oh / n

        best_s = None
        best_perp2 = np.inf

        for w in centers:
            d = _pbc_delta(w - rO, L)
            s = float(np.dot(d, u))  # position along O->H
            w_par = s * u
            perp2 = float(np.dot(d - w_par, d - w_par))
            if perp2 < best_perp2:
                best_perp2 = perp2
                best_s = s

        if best_s is None:
            return np.array([np.nan], dtype=float)

        s01 = max(0.0, min(1.0, best_s / n))
        return np.array([s01], dtype=float)


# -------------------------------------------------------------------------
# 3) ElectronicZundelSymmetryCV
# -------------------------------------------------------------------------

@dataclass(slots=True)
class ElectronicZundelSymmetryCV:
    """
    Elektronisk Zundel-symmetri mellom donor (O_d) og akseptor (O_a),
    basert på Wannier- eller HOMO-sentre.

    Geometri:
      - midtpunkt M = (O_d + O_a)/2
      - akse e = enhetsvektor langs O_d → O_a

    For hvert senter C:
      v = MIC-vektor M → C
      s = v · e             (signert koordinat langs O_d–O_a)
      r_perp = ||v - s e||  (perpendikulær avstand til aksen)

    Vi bruker bare sentre med:
      |s| <= S_max    og    r_perp <= R_perp_max

    Teller:
      N_d  = #sentere med s < 0 (donorside)
      N_a  = #sentere med s > 0 (akseptorside)
      asym_N = N_a - N_d
      mean_s = gjennomsnittlig s (hvis minst ett senter, ellers NaN)

    Output:
      [N_d, N_a, asym_N, mean_s]
    """

    name: str = "electronic_zundel_symmetry"
    S_max: float = 3.0       # Å langs aksen fra midtpunktet
    R_perp_max: float = 3.0  # Å i tverrsnitt rundt aksen

    labels: Tuple[str, ...] = field(
        default=("N_elec_d", "N_elec_a", "asym_N", "mean_s"), init=False
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L: Optional[float] = getattr(inputs, "box", None)
        rc = getattr(inputs, "reaction", None)

        if rc is None:
            return np.full((4,), np.nan, dtype=float)

        try:
            O_d = int(rc.O_d)
            O_a = int(rc.O_a)
        except Exception:
            return np.full((4,), np.nan, dtype=float)

        N_atoms = coords.shape[0]
        if not (0 <= O_d < N_atoms and 0 <= O_a < N_atoms):
            return np.full((4,), np.nan, dtype=float)

        # Elektronsentre: wannier_centers først, ellers homo_centers
        centers = getattr(inputs, "wannier_centers", None)
        if centers is None:
            centers = getattr(inputs, "homo_centers", None)
        if centers is None or centers.size == 0:
            return np.full((4,), np.nan, dtype=float)

        # Geometri
        mid = 0.5 * (coords[O_d] + coords[O_a])
        e_axis = _unit(_pbc_delta(coords[O_a] - coords[O_d], L))

        # Vektorer M → C (MIC)
        vecs = _pbc_delta(centers - mid, L)
        s = vecs @ e_axis                      # projeksjon langs aksen
        proj = np.outer(s, e_axis)            # s e
        perp = vecs - proj
        r_perp = np.linalg.norm(perp, axis=1)

        mask = (np.abs(s) <= self.S_max) & (r_perp <= self.R_perp_max)
        if not np.any(mask):
            return np.array([0.0, 0.0, 0.0, np.nan], dtype=float)

        s_loc = s[mask]

        N_d = float(np.sum(s_loc < 0.0))
        N_a = float(np.sum(s_loc > 0.0))
        asym_N = float(N_a - N_d)
        mean_s = float(np.mean(s_loc)) if s_loc.size > 0 else np.nan

        return np.array([N_d, N_a, asym_N, mean_s], dtype=float)

from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np


@dataclass(slots=True)
class ElectronicPresolvationCV:
    """
    Elektronisk presolvation rundt center-O (typisk O_a):

    Vi teller Wannier-/HOMO-sentre i to radielle skall:

        første skall:  r <= R1_elec
        andre skall :  R1_elec < r <= R2_elec

    center-O velges som:
        if use_donor_O=True  -> rc.O_d
        else                 -> rc.O_a

    Elektronsentre:
        - bruker inputs.wannier_centers hvis finnes,
        - ellers inputs.homo_centers
        - hvis ingen av delene finnes -> NaN

    Output:
        [N1_elec, N2_elec, DeltaN_elec=N2_elec-N1_elec]
    """
    name: str = "electronic_presolvation"

    R1_elec: float = 3.0   # Å – første elektronskall rundt center-O
    R2_elec: float = 5.0   # Å – andre elektronskall rundt center-O
    use_donor_O: bool = False   # default: bruk O_a (akseptor)

    labels: Tuple[str, ...] = field(
        default=("N1_elec", "N2_elec", "DeltaN_elec"), init=False
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L: Optional[float] = getattr(inputs, "box", None)
        rc = getattr(inputs, "reaction", None)

        if rc is None:
            return np.full((3,), np.nan, dtype=float)

        # center-O: donor eller akseptor
        try:
            center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        except Exception:
            return np.full((3,), np.nan, dtype=float)

        N_atoms = coords.shape[0]
        if not (0 <= center_O < N_atoms):
            return np.full((3,), np.nan, dtype=float)

        # Elektronsentre: Wannier først, ellers HOMO
        centers = getattr(inputs, "wannier_centers", None)
        if centers is None:
            centers = getattr(inputs, "homo_centers", None)
        if centers is None or centers.size == 0:
            return np.full((3,), np.nan, dtype=float)

        # Vektorer center_O → C (MIC)
        vecs = _pbc_delta(centers - coords[center_O], L)
        r = np.linalg.norm(vecs, axis=1)

        mask1 = r <= self.R1_elec
        mask2 = (r > self.R1_elec) & (r <= self.R2_elec)

        N1 = float(np.sum(mask1))
        N2 = float(np.sum(mask2))
        DeltaN = float(N2 - N1)

        return np.array([N1, N2, DeltaN], dtype=float)
