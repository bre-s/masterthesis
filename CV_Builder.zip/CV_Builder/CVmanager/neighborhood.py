# CVmanager/neighborhood.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Literal
import numpy as np

try:
    from CVmanager.reaction_center import ReactionCenter
except Exception:
    # Fallback import path if package name differs
    from reaction_center import ReactionCenter  # type: ignore

def _mic_delta(a: np.ndarray, b: np.ndarray, box: Optional[float]) -> np.ndarray:
    d = b - a
    if box is not None and box > 0:
        d -= np.rint(d / box) * box
    return d

def _mic_dist(a: np.ndarray, b: np.ndarray, box: Optional[float]) -> float:
    return float(np.linalg.norm(_mic_delta(a, b, box)))

@dataclass(slots=True)
class ReactionNeighborhood:
    """
    Per-frame neighborhood centered on the reaction-center donor oxygen O_d.
    All indices are in the **invariant** index space (aligned with names_ref).
    """
    center_O: int                     # O_d (donor oxygen)
    Hs: int                           # H* index (invariant)
    O_indices: np.ndarray             # (K,) oxygen indices by ascending distance
    O_labels: np.ndarray              # (K,) human-readable labels for O_indices
    H_pairs: np.ndarray               # (K,2) hydrogens (H1,H2) for each neighbor water (unordered, original invariant order)
    H_pairs_by_rule: np.ndarray       # (K,2) hydrogens sorted by the chosen rule (e.g., distance to H*)
    d_OO: np.ndarray                  # (K,) distances O_d -> O_k (MIC)

    def rank_map(self) -> np.ndarray:
        """Return the rank → oxygen invariant index mapping (shape (K,))."""
        return self.O_indices

    def rank_labels(self) -> np.ndarray:
        """Return the rank → human label mapping for oxygens (shape (K,))."""
        return self.O_labels

def build_neighborhood(
    coords: np.ndarray,
    water_triplets: np.ndarray,
    rc: ReactionCenter,
    K: int = 12,
    box: Optional[float] = None,
    names_ref: Optional[np.ndarray] = None,
    include_self: bool = True,
    metric: Literal["OO"] = "OO",
    h_rank_mode: Literal["to_Hstar", "to_Od"] = "to_Hstar",
    tie_tol: float = 1e-10,
) -> ReactionNeighborhood:
    """Select the K nearest **water oxygens** to the donor oxygen O_d.

    Parameters
    ----------
    coords : (N,3) float
        Invariant-ordered coordinates.
    water_triplets : (nW,3) int
        (H1, O, H2) indices in invariant order for each water.
    rc : ReactionCenter
        Precomputed reaction center for this frame (provides O_d and Hs).
    K : int
        Number of neighbors to return (after optional self-inclusion).
    box : float | None
        Cubic box length (Å). If None or 0, no PBC applied.
    names_ref : array[str] | None
        Human-readable names aligned to invariant indices. Used to build O_labels if provided.
    include_self : bool
        If True, rank 0 will be the **donor water** itself (its oxygen O_d).
    metric : Literal["OO"]
        Distance metric for oxygen ranking. Currently only "OO" (O_d → O_k) is supported.
    h_rank_mode : Literal["to_Hstar", "to_Od"]
        How to sort each neighbor water's two hydrogens:
            - "to_Hstar": ascending distance to H* (rc.Hs)
            - "to_Od":    ascending distance to O_d
    tie_tol : float
        If two oxygens have distances within this tolerance, break ties by invariant index for stability.

    Returns
    -------
    ReactionNeighborhood
    """
    O_d, Hs = int(rc.O_d), int(rc.Hs)

    # Map O → (H1, H2) from water_triplets
    # Each row is (H1, O, H2) in invariant indices
    O_list = water_triplets[:, 1].astype(int)
    H_pairs = water_triplets[:, [0, 2]].astype(int)
    # Build arrays to compute distances to each oxygen
    # Optionally exclude the donor water when building candidates
    candidates = O_list.copy()
    if not include_self:
        candidates = candidates[candidates != O_d]

    # Compute distances from O_d to each candidate oxygen
    dists = np.array([_mic_dist(coords[O_d], coords[o], box) for o in candidates], dtype=float)

    # Stable argsort with tie-breaker by oxygen index
    # First order by (distance, oxygen index)
    order = np.lexsort((candidates, np.round(dists / max(tie_tol, 1e-20)).astype(np.int64)))
    # But np.lexsort sorts by last key fastest; use tuple (dists, candidates) directly for clarity
    # We'll implement stable ranking manually:
    pairs = list(zip(dists.tolist(), candidates.tolist()))
    pairs.sort(key=lambda t: (round(t[0] / max(tie_tol, 1e-20)), t[1]))

    # Take top K
    use = pairs[:K] if K is not None and K > 0 else pairs
    O_sel = np.array([o for _, o in use], dtype=int)
    d_sel = np.array([float(d) for d, _ in use], dtype=float)

    # Build (H1, H2) for each selected oxygen
    # For each O_k in O_sel, find its row in O_list to get the corresponding hydrogens
    # Since indices are invariant and unique per water, this is 1:1
    idx_lookup = {int(o): i for i, o in enumerate(O_list)}
    H_for_O = np.array([H_pairs[idx_lookup[int(o)]] for o in O_sel], dtype=int)

    # Hydrogen ordering by rule
    if h_rank_mode == "to_Hstar":
        a = np.broadcast_to(coords[Hs], H_for_O.shape + (3,))
        b = coords[H_for_O]
        dH = np.linalg.norm(_mic_delta(a, b, box), axis=2)
    else:  # "to_Od"
        a = np.broadcast_to(coords[O_d], H_for_O.shape + (3,))
        b = coords[H_for_O]
        dH = np.linalg.norm(_mic_delta(a, b, box), axis=2)

    # argsort along the last axis (2 hydrogens) -> indices [0,1] in ascending distance
    h_order = np.argsort(dH, axis=1)
    rows = np.arange(H_for_O.shape[0])[:, None]
    H_sorted = H_for_O[rows, h_order]

    # Human labels (optional)
    if names_ref is not None:
        O_labels = np.asarray(names_ref, dtype=object)[O_sel].astype(str)
    else:
        O_labels = np.array([str(o) for o in O_sel], dtype=object)

    return ReactionNeighborhood(
        center_O=O_d, Hs=Hs,
        O_indices=O_sel,
        O_labels=O_labels,
        H_pairs=H_for_O,
        H_pairs_by_rule=H_sorted,
        d_OO=d_sel,
    )