from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n if n else 1.0)


def _hb_acceptor_mask_shell(
    coords: np.ndarray,
    H1: int,
    O0: int,
    H2: int,
    O_all: np.ndarray,
    R_min: float,
    R_max: float,
    angle_min_deg: float,
    L: Optional[float],
) -> np.ndarray:
    """
    H-bond akseptorer til O0 (som donor) innenfor skall [R_min, R_max].
    """
    cos_cut = float(np.cos(np.deg2rad(angle_min_deg)))
    rmin2 = float(R_min ** 2)
    rmax2 = float(R_max ** 2)

    Opos0 = coords[O0]
    d = coords[O_all] - Opos0
    if L is not None and L > 0:
        d = d - np.rint(d / L) * L

    r2 = np.einsum("ij,ij->i", d, d)
    shell = (r2 >= rmin2) & (r2 <= rmax2) & (r2 > 0.0)
    if not np.any(shell):
        return np.zeros_like(shell, dtype=bool)

    u = np.zeros_like(d)
    nz = np.linalg.norm(d[shell], axis=1)
    u[shell] = (d[shell].T / (nz + 1e-20)).T

    v1 = _unit(_pbc_delta(coords[H1] - Opos0, L))
    v2 = _unit(_pbc_delta(coords[H2] - Opos0, L))
    ang_ok = (u @ v1 >= cos_cut) | (u @ v2 >= cos_cut)

    return shell & ang_ok


@dataclass(slots=True)
class SecondShellAcceptorsCV:
    """
    Antall H-bond akseptorer i ANDRE skall rundt reaksjonssenteret
    (center O som donor).

    Første skall typisk R < R1, andre skall R1 < R <= R2.

    Center oxygen:
        if use_donor_O=True  -> rc.O_d
        else                 -> rc.O_a

    Output:
        [n2_acceptors]
    """
    name: str = "second_shell_acceptors"
    R1: float = 3.5
    R2: float = 5.0
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("n2_acceptors",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        wtrip = inputs.water_triplets

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        mask = _hb_acceptor_mask_shell(
            inputs.coords,
            h1,
            o0,
            h2,
            O_all,
            self.R1,
            self.R2,
            self.angle_min_deg,
            getattr(inputs, "box", None),
        )
        n2 = float(np.count_nonzero(mask))
        return np.array([n2], dtype=float)


@dataclass(slots=True)
class DeltaN1N2_CV:
    """
    Forskjell i antall akseptorer i første og andre skall:

        Δn = n_a(1st) - n_a(2nd)

    Første skall: R <= R1_max
    Andre skall : R1_max < R <= R2_max

    Output:
        [Delta_n]
    """
    name: str = "delta_n1n2"
    R1_max: float = 3.5
    R2_max: float = 5.0
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    labels: Tuple[str, ...] = ("Delta_n1n2",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        wtrip = inputs.water_triplets

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)
        L = getattr(inputs, "box", None)

        # Første skall: [0, R1_max]
        mask1 = _hb_acceptor_mask_shell(
            inputs.coords,
            h1,
            o0,
            h2,
            O_all,
            0.0,
            self.R1_max,
            self.angle_min_deg,
            L,
        )
        # Andre skall: (R1_max, R2_max]
        mask2 = _hb_acceptor_mask_shell(
            inputs.coords,
            h1,
            o0,
            h2,
            O_all,
            self.R1_max,
            self.R2_max,
            self.angle_min_deg,
            L,
        )

        n1 = float(np.count_nonzero(mask1))
        n2 = float(np.count_nonzero(mask2))
        return np.array([n1 - n2], dtype=float)


@dataclass(slots=True)
class DualPresolvationIndicatorCV:
    """
    Dual presolvation-indikator (Liu 2023-inspirert):

    1) Første skall hyperkoordinert: n_a(1st) == 4
    2) Minst én andre-skalls-nabo er underkoordinert: n_hb <= undercoord_max

    Her definerer vi:
        - n_a(1st) via H-bond akseptorer i første skall
        - n_hb for andre skall som totalt antall H-bonds (don+acc) for nabo-O

    Output:
        [Pi_dual] (0.0 eller 1.0)
    """
    name: str = "dual_presolvation_indicator"
    R1: float = 3.5
    R2: float = 5.0
    angle_min_deg: float = 150.0
    use_donor_O: bool = True
    undercoord_max: int = 2
    labels: Tuple[str, ...] = ("Pi_dual",)

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.array([np.nan], dtype=float)

        coords = inputs.coords
        L = getattr(inputs, "box", None)
        wtrip = inputs.water_triplets  # H1,O,H2
        center_O = int(rc.O_d if self.use_donor_O else rc.O_a)

        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            return np.array([0.0], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        # n_a(1st)
        mask1 = _hb_acceptor_mask_shell(
            coords,
            h1,
            o0,
            h2,
            O_all,
            0.0,
            self.R1,
            self.angle_min_deg,
            L,
        )
        n1 = int(np.count_nonzero(mask1))
        hyper = (n1 == 4)

        # finn andre-skalls naboer
        mask2 = _hb_acceptor_mask_shell(
            coords,
            h1,
            o0,
            h2,
            O_all,
            self.R1,
            self.R2,
            self.angle_min_deg,
            L,
        )
        second_indices = O_all[mask2]

        if len(second_indices) == 0 or not hyper:
            # enten ingen andre-skall, eller ikke hyperkoordinert i første
            return np.array([0.0], dtype=float)

        # For hver andre-skalls O, anslå totalt antall H-bonds (don+acc) med et enkelt kriterium:
        #   - nabo O' med |O-O'| <= R1 og som oppfyller donor-kriteriet fra
        #     enten denne O eller den andre.
        cos_cut = float(np.cos(np.deg2rad(self.angle_min_deg)))
        rcut2 = float(self.R1 ** 2)

        def total_hb_count_for_O(Ox: int) -> int:
            # hent H1,H2 for Ox
            rowx = np.where(wtrip[:, 1] == Ox)[0]
            if len(rowx) == 0:
                return 0
            hx1, ox0, hx2 = map(int, wtrip[rowx[0]])

            count = 0
            for (h1p, op, h2p) in wtrip.astype(int):
                if op == Ox:
                    continue
                # sjekk avstand
                d = _pbc_delta(coords[op] - coords[Ox], L)
                r2 = float(d @ d)
                if r2 <= 0.0 or r2 > rcut2:
                    continue
                u = _unit(d)
                # donor-kjegle ved Ox
                v1x = _unit(_pbc_delta(coords[hx1] - coords[Ox], L))
                v2x = _unit(_pbc_delta(coords[hx2] - coords[Ox], L))
                donor_from_Ox = (u @ v1x >= cos_cut) or (u @ v2x >= cos_cut)
                # donor-kjegle ved O'
                v1p = _unit(_pbc_delta(coords[h1p] - coords[op], L))
                v2p = _unit(_pbc_delta(coords[h2p] - coords[op], L))
                donor_from_Op = (u @ v1p <= -cos_cut) or (u @ v2p <= -cos_cut)  # grovt "motsatt" retning
                if donor_from_Ox or donor_from_Op:
                    count += 1
            return count

        under = False
        for Ox in second_indices:
            if total_hb_count_for_O(int(Ox)) <= self.undercoord_max:
                under = True
                break

        Pi_dual = 1.0 if (hyper and under) else 0.0
        return np.array([Pi_dual], dtype=float)




@dataclass(slots=True)
class DANeighborRatiosCV:
    """
    Distance ratio CVs around the donor–acceptor pair (O_d, O_a).

    Definitions:
        D1 = |O_a - O_d|
        D2 = min_{O != O_d,O_a} |O - O_d|   (nearest oxygen to O_d, excluding O_a)
        D3 = min_{O != O_d,O_a} |O - O_a|   (nearest oxygen to O_a, excluding O_d)

    Outputs:
        D1_over_D2 = D1 / D2
        D1_over_D3 = D1 / D3
        D2_over_D3 = D2 / D3

    Intuition:
      - D1 is the proton-transfer distance (Zundel-like).
      - D2 tells how close O_d is to "other" waters (potential new donor/acceptor).
      - D3 tells how close O_a is to "other" waters (potential next proton hop).

      Ratios encode presolvation / competition between current DA-pair and other neighbors.
    """
    name: str = "DA_neighbor_ratios"

    labels: Tuple[str, ...] = field(
        default=("D1_over_D2", "D1_over_D3", "D2_over_D3"),
        init=False,
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L: Optional[float] = getattr(inputs, "box", None)
        rc = getattr(inputs, "reaction", None)
        neigh = getattr(inputs, "neighborhood", None)
        water_triplets = getattr(inputs, "water_triplets", None)

        n_out = len(self.labels)
        out = np.full((n_out,), np.nan, dtype=float)

        # Basic sanity: need reaction center + water topology
        if rc is None or water_triplets is None or coords is None:
            return out

        # Extract O_d and O_a as integers and check bounds
        try:
            O_d = int(rc.O_d)
            O_a = int(rc.O_a)
        except Exception:
            return out

        N = coords.shape[0]
        if not (0 <= O_d < N and 0 <= O_a < N):
            return out

        # --- D1: distance between O_d and O_a ---
        d_vec = _pbc_delta(coords[O_a] - coords[O_d], L)
        D1 = float(np.linalg.norm(d_vec))

        # --- helper: all oxygen indices from water_triplets ---
        try:
            wt = np.asarray(water_triplets, dtype=int)
            O_all = np.unique(wt[:, 1])  # assuming (H1, O, H2)
        except Exception:
            O_all = np.array([], dtype=int)

        # --- D2: nearest oxygen to O_d, excluding O_d and O_a ---

        D2 = np.nan

        # Prefer neighborhood if available (it is centered on O_d)
        if neigh is not None:
            O_indices = np.asarray(getattr(neigh, "O_indices", []), dtype=int)
            d_OO = np.asarray(getattr(neigh, "d_OO", []), dtype=float)

            if O_indices.size > 0 and O_indices.size == d_OO.size:
                mask = (O_indices != O_d) & (O_indices != O_a)
                if np.any(mask):
                    D2 = float(np.min(d_OO[mask]))

        # Fallback: brute-force over all oxygens
        if not np.isfinite(D2) and O_all.size > 0:
            mask = (O_all != O_d) & (O_all != O_a)
            cand = O_all[mask]
            if cand.size > 0:
                vecs = _pbc_delta(coords[cand] - coords[O_d], L)
                dists = np.linalg.norm(vecs, axis=1)
                D2 = float(np.min(dists))

        # --- D3: nearest oxygen to O_a, excluding O_d and O_a ---

        D3 = np.nan
        if O_all.size > 0:
            mask = (O_all != O_d) & (O_all != O_a)
            cand = O_all[mask]
            if cand.size > 0:
                vecs = _pbc_delta(coords[cand] - coords[O_a], L)
                dists = np.linalg.norm(vecs, axis=1)
                D3 = float(np.min(dists))

        # --- Compute ratios safely ---
        eps = 1e-12

        if np.isfinite(D1) and np.isfinite(D2) and D2 > eps:
            out[0] = D1 / D2  # D1_over_D2

        if np.isfinite(D1) and np.isfinite(D3) and D3 > eps:
            out[1] = D1 / D3  # D1_over_D3

        if np.isfinite(D2) and np.isfinite(D3) and D3 > eps:
            out[2] = D2 / D3  # D2_over_D3

        return out


@dataclass(slots=True)
class ElectronicDualPresolvationCV:
    """
    Elektronisk analog til DualPresolvationIndicatorCV.

    Idé:
      1) Første elektronskall rundt center-O er "hyper-presolvated":
            N1_elec >= N1_hyper_min
         hvor N1_elec er #Wannier/HOMO-sentre innenfor R1_elec rundt center-O.

      2) Minst én O i andre O–O-skall (R1_OO <= |O_center - O'| <= R2_OO)
         er elektronisk underpresolvated:
            N_elec_local(O') <= undercoord_max_elec
         der N_elec_local(O') er antall elektronsentre innenfor R_elec_local
         rundt O'.

    center-O velges som:
        if use_donor_O=True  -> rc.O_d
        else                 -> rc.O_a

    Elektronsentre:
        - inputs.wannier_centers hvis finnes
        - ellers inputs.homo_centers

    Output:
        [Pi_elec_dual, N1_elec, min_N_elec_second]

        Pi_elec_dual = 1.0 hvis (hyper-presolvation i første skall) OG
                              (minst én andre-skalls O er elektronisk under-koordinert)
                     = 0.0 ellers

        N1_elec = antall elektronsentre i første skall rundt center-O
        min_N_elec_second = minimum N_elec_local(O') over andre-skalls O'
                            (NaN hvis ingen such O' eller ingen elektrondata)
    """
    name: str = "electronic_dual_presolvation"

    # O–O-geometriparametere (som i DualPresolvationIndicatorCV)
    R1_OO: float = 3.5
    R2_OO: float = 5.0
    angle_min_deg: float = 150.0
    use_donor_O: bool = False  # default: O_a

    # Elektronradier
    R1_elec: float = 3.0      # første elektronskall rundt center-O
    R2_elec: float = 5.0      # (hovedsakelig brukt i ElectronicPresolvationCV, men vi kan matche)
    R_elec_local: float = 3.0 # radius rundt andre-skalls O for lokal elektron-telling

    # Terskler
    N1_hyper_min: int = 4         # hyper-presolvation i første skall
    undercoord_max_elec: int = 2  # under-koordinasjon rundt andre-skalls O

    labels: Tuple[str, ...] = field(
        default=("Pi_elec_dual", "N1_elec", "min_N_elec_second"),
        init=False,
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L: Optional[float] = getattr(inputs, "box", None)
        wtrip: np.ndarray = inputs.water_triplets
        rc = getattr(inputs, "reaction", None)

        # Default retur hvis noe mangler
        base_nan = np.array([np.nan, np.nan, np.nan], dtype=float)

        if rc is None:
            return base_nan

        # center-O
        try:
            center_O = int(rc.O_d if self.use_donor_O else rc.O_a)
        except Exception:
            return base_nan

        N_atoms = coords.shape[0]
        if not (0 <= center_O < N_atoms):
            return base_nan

        # Elektronsentre
        centers = getattr(inputs, "wannier_centers", None)
        if centers is None:
            centers = getattr(inputs, "homo_centers", None)
        if centers is None or centers.size == 0:
            return base_nan

        # ----------------------
        # 1) Første elektronskall rundt center-O
        # ----------------------
        vecs_center = _pbc_delta(centers - coords[center_O], L)
        r_center = np.linalg.norm(vecs_center, axis=1)

        mask1 = r_center <= self.R1_elec
        N1_elec = float(np.sum(mask1))

        hyper = (N1_elec >= float(self.N1_hyper_min))

        # ----------------------
        # 2) Finn andre O–O-skalls naboer til center-O
        # ----------------------
        # Finn H1,H2 til center_O for å kunne bruke hb-acceptor-masken
        row = np.where(wtrip[:, 1] == center_O)[0]
        if len(row) == 0:
            # uten H-informasjon gir det lite mening å definere O–O-skall
            Pi = 0.0 if hyper else 0.0
            return np.array([Pi, N1_elec, np.nan], dtype=float)

        h1, o0, h2 = map(int, wtrip[row[0]])
        O_all = wtrip[:, 1].astype(int)

        mask_second = _hb_acceptor_mask_shell(
            coords,
            h1,
            o0,
            h2,
            O_all,
            self.R1_OO,
            self.R2_OO,
            self.angle_min_deg,
            L,
        )
        second_indices = O_all[mask_second]

        if len(second_indices) == 0:
            # ingen andre-skalls naboer
            Pi = 0.0 if hyper else 0.0
            return np.array([Pi, N1_elec, np.nan], dtype=float)

        # ----------------------
        # 3) Lokal elektron-telling rundt hver andre-skalls O
        # ----------------------
        local_counts = []
        for Ox in second_indices.astype(int):
            if not (0 <= Ox < N_atoms):
                continue
            v = _pbc_delta(centers - coords[Ox], L)
            rloc = np.linalg.norm(v, axis=1)
            count = int(np.sum(rloc <= self.R_elec_local))
            local_counts.append(count)

        if not local_counts:
            Pi = 0.0 if hyper else 0.0
            return np.array([Pi, N1_elec, np.nan], dtype=float)

        min_local = float(min(local_counts))
        under = (min_local <= float(self.undercoord_max_elec))

        Pi_elec_dual = 1.0 if (hyper and under) else 0.0

        return np.array([Pi_elec_dual, N1_elec, min_local], dtype=float)
