from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np


def _pbc_delta(d: np.ndarray, L: Optional[float]) -> np.ndarray:
    if L is None or L <= 0:
        return d
    return d - L * np.rint(d / L)


def _mic_dist(a: np.ndarray, b: np.ndarray, L: Optional[float]) -> float:
    return float(np.linalg.norm(_pbc_delta(b - a, L)))


@dataclass(slots=True)
class ZundelCoordinateCV:
    """
    Klassisk Zundel-koordinat for protonoverføring.

    Definisjon:
        R_OdH  = |O_d - H*|
        R_OaH  = |O_a - H*|
        delta  = R_OdH - R_OaH
        R_OdOa = |O_d - O_a|

    Output:
        [delta, R_OdH, R_OaH, R_OdOa]
    """
    name: str = "zundel_coordinate"
    labels: Tuple[str, ...] = ("delta", "R_OdH", "R_OaH", "R_OdOa")

    def compute(self, inputs) -> np.ndarray:
        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.full((4,), np.nan, dtype=float)

        coords: np.ndarray = inputs.coords
        L = getattr(inputs, "box", None)

        O_d = int(rc.O_d)
        O_a = int(rc.O_a)
        Hs = int(getattr(rc, "Hs", -1))

        if Hs < 0:
            return np.full((4,), np.nan, dtype=float)

        R_OdH = _mic_dist(coords[O_d], coords[Hs], L)
        R_OaH = _mic_dist(coords[O_a], coords[Hs], L)
        R_OdOa = _mic_dist(coords[O_d], coords[O_a], L)

        delta = R_OdH - R_OaH

        return np.array([delta, R_OdH, R_OaH, R_OdOa], dtype=float)
