from __future__ import annotations
from dataclasses import dataclass, field
from typing import Tuple
import numpy as np

try:
    # Din eksisterende WannierGeomCV
    from CVmanager.wannier_geom import WannierGeomCV as _BaseWannierCV
except Exception:
    _BaseWannierCV = None


@dataclass(slots=True)
class WannierRCFeaturesCV:
    """
    Thin wrapper that computes the 8 base Wannier features for the *current*
    reaction center only, reusing your original WannierGeomCV.

    Ingen K, ingen nabo-ranging – bare RC.

    Expects:
        inputs.water_triplets : (nW,3) H1,O,H2 in invariant order
        inputs.ho_pairs       : (2*nO,2) (O,H) pairs in invariant order
        inputs.reaction       : ReactionCenter (O_d, O_a, Hs, etc.)

    Output (8 features, same order as base WannierGeomCV):
        donor_center_r_mean
        donor_center_r_std
        donor_proj_max_along_OHstar
        donor_proj_min_along_OHstar
        accept_center_r_mean
        accept_center_r_std
        accept_proj_max_along_OaHstar
        accept_proj_min_along_OaHstar
    """
    name: str = "wannier_rc_features"
    require_exact_four: bool = False

    labels: Tuple[str, ...] = (
        "donor_center_r_mean",
        "donor_center_r_std",
        "donor_proj_max_along_OHstar",
        "donor_proj_min_along_OHstar",
        "accept_center_r_mean",
        "accept_center_r_std",
        "accept_proj_max_along_OaHstar",
        "accept_proj_min_along_OaHstar",
    )

    _base: object | None = field(default=None, init=False)

    def _ensure_base(self, inputs) -> None:
        if self._base is not None:
            return
        if _BaseWannierCV is None:
            raise RuntimeError("WannierGeomCV not available to import")

        wtrip = getattr(inputs, "water_triplets", None)
        ho_pairs = getattr(inputs, "ho_pairs", None)
        if wtrip is None or ho_pairs is None:
            raise ValueError("WannierRCFeaturesCV requires inputs.water_triplets and inputs.ho_pairs")

        oxygen_indices = wtrip[:, 1].astype(int)

        self._base = _BaseWannierCV(
            name="_wannier_rc_base",
            oxygen_indices=oxygen_indices,
            ho_pairs=ho_pairs,
            require_exact_four=self.require_exact_four,
        )

    def compute(self, inputs) -> np.ndarray:
        self._ensure_base(inputs)

        vals = self._base.compute(inputs)
        vals = np.asarray(vals, dtype=float).reshape(-1)

        if vals.size != 8:
            out = np.full((8,), np.nan, dtype=float)
            out[:min(8, vals.size)] = vals[:min(8, vals.size)]
            return out

        return vals


@dataclass(slots=True)
class WannierAtAcceptorDirectionalCV:
    """
    Retningsfølsom Wannier/HOMO-CV ved akseptor-oksigenet O_a.

    Idé:
      - Finn O_a og de to kovalente hydrogenene (Ha, Hb) fra water_triplets.
      - Definér H_long og H_short basert på O_a–H-bondlengde
            H_long  = H med lengst O_a–H
            H_short = H med kortest O_a–H
      - Bruk H* (rc.Hs) som "incoming" retning hvis tilgjengelig.
      - For hvert Wannier/HOMO-senter C nær O_a (|O_a–C| <= R_cut):
            n        = enhetsvektor O_a -> C
            cos_in   = n · ê_in      (ê_in = O_a -> H*)
            cos_long = n · ê_long    (ê_long  = O_a -> H_long)
            cos_short= n · ê_short   (ê_short = O_a -> H_short)

      - Returnerer aggregater:
            N_loc        = antall sentre i kulen rundt O_a
            mean_cos_in
            mean_cos_long
            mean_cos_short

    Hvis H* mangler eller er utenfor gyldig indeks, settes mean_cos_in = NaN.
    Hvis ingen sentre er innenfor R_cut, blir:
        [N_loc, mean_cos_in, mean_cos_long, mean_cos_short] = [0.0, NaN, NaN, NaN]
    """
    name: str = "wannier_acceptor_directional"
    R_cut: float = 3.0  # cutoff rundt O_a for hvilke sentre som tas med

    labels: Tuple[str, ...] = field(
        default=("N_wann_Oa", "mean_cos_in", "mean_cos_long", "mean_cos_short"),
        init=False,
    )

    def compute(self, inputs) -> np.ndarray:
        coords: np.ndarray = inputs.coords
        L: Optional[float] = getattr(inputs, "box", None)
        wtrip: np.ndarray = inputs.water_triplets

        rc = getattr(inputs, "reaction", None)
        if rc is None:
            return np.full((4,), np.nan, dtype=float)

        # Velg O_a som senter
        try:
            O_a = int(rc.O_a)
        except Exception:
            return np.full((4,), np.nan, dtype=float)

        N = coords.shape[0]
        if not (0 <= O_a < N):
            return np.full((4,), np.nan, dtype=float)

        # Finn de to kovalente H-ene rundt O_a fra water_triplets (H1,O,H2)
        row = np.where(wtrip[:, 1] == O_a)[0]
        if len(row) == 0:
            return np.full((4,), np.nan, dtype=float)
        h1, o0, h2 = map(int, wtrip[row[0]])

        # Definér H_long og H_short via bondlengde O_a–H
        r1 = _mic_dist(coords[O_a], coords[h1], L)
        r2 = _mic_dist(coords[O_a], coords[h2], L)
        if r1 >= r2:
            H_long, H_short = h1, h2
        else:
            H_long, H_short = h2, h1

        # Enhetsvektorer fra O_a
        e_long = _unit(_pbc_delta(coords[H_long] - coords[O_a], L))
        e_short = _unit(_pbc_delta(coords[H_short] - coords[O_a], L))

        # Incoming retning: O_a -> H* hvis tilgjengelig
        e_in = None
        Hs = getattr(rc, "Hs", None)
        if Hs is not None:
            try:
                Hs_idx = int(Hs)
                if 0 <= Hs_idx < N:
                    v_in = _pbc_delta(coords[Hs_idx] - coords[O_a], L)
                    if np.linalg.norm(v_in) > 1e-8:
                        e_in = _unit(v_in)
            except Exception:
                e_in = None

        # Velg hvilke "elektronsentre" vi bruker: wannier_centers først, ellers homo_centers
        centers = getattr(inputs, "wannier_centers", None)
        if centers is None:
            centers = getattr(inputs, "homo_centers", None)
        if centers is None:
            # ingen elektron-sentre tilgjengelig
            return np.full((4,), np.nan, dtype=float)

        # Vektorer fra O_a til alle sentre
        vecs = _pbc_delta(centers - coords[O_a], L)
        r = np.linalg.norm(vecs, axis=1)
        mask = r <= self.R_cut
        if not np.any(mask):
            # ingen sentre i kulen rundt O_a
            return np.array([0.0, np.nan, np.nan, np.nan], dtype=float)

        vecs_loc = vecs[mask]
        r_loc = r[mask]
        n_vecs = vecs_loc / (r_loc[:, None] + 1e-20)

        # Projeksjoner
        # 1) mot incoming akse (H*)
        if e_in is not None:
            cos_in = n_vecs @ e_in
            mean_cos_in = float(np.mean(cos_in))
        else:
            mean_cos_in = np.nan

        # 2) mot H_long
        cos_long = n_vecs @ e_long
        mean_cos_long = float(np.mean(cos_long))

        # 3) mot H_short
        cos_short = n_vecs @ e_short
        mean_cos_short = float(np.mean(cos_short))

        N_loc = float(len(r_loc))

        return np.array(
            [N_loc, mean_cos_in, mean_cos_long, mean_cos_short],
            dtype=float,
        )
