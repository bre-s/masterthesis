#!/usr/bin/env python3
"""
Aggregate CVs from step_*.h5 into a sorted HDF5 matrix for PPA.

For each grid_id (e.g. 100) it writes:

  - root dataset "lambda_and_weight" with labels:
        ["RETIS_step", "lambda_max", "weight"]

  - group "/<grid_id>/<module>/" with datasets:
        "cv"   : 2D float matrix, shape (n_steps, 1 + n_features)
        "cols" : string array ["RETIS_step", "<prefix>::<feat1>", ...]

    where <module> er cv.name fra SimulationRunner/H5Writer, f.eks.
        "wire_compression", "zundel_coordinate", "E_parallel", ...

  - group "/<grid_id>/neighbor_all/" som er en horisontal concat av alle
    valgte moduler:
        "cv"   : [RETIS_step, <mod1-cols...>, <mod2-cols...>, ...]
        "cols" : ["RETIS_step", "mod1::feat1", ..., "mod2::featK", ...]

Valg av moduler:
  - Hvis du gir --modules, brukes nøyaktig de navnene.
  - Hvis du ikke gir --modules, auto-discoverer vi ALLE grupper under /<grid_id>
    i step-filene, bortsett fra:
        - "pair_dist_all_atoms"  (reservert for --include-standard)
        - "neighbor_all"         (lages av dette scriptet, finnes ikke i step_*.h5)
        - "standard"             (bare i ferdig fil)

Parallellisering:
  - Scriptet kan kjøres i MPI/Slurm med flere tasks.
  - Med --shard-steps-env fordeles step_*.h5 jevnt mellom ranks via
    SLURM_PROCID / SLURM_NTASKS.
  - Hver rank skriver sin egen <out>.part.<rank>.h5 som kan brukes av PPA
    direkte, eller merges videre hvis ønskelig.

Typisk bruk (med MPI-sharding):
  python sorted_h5_all.py \\
      --steps-dir  CVs/200 \\
      --out        CVs/200/sorted/mat_all.h5 \\
      --all-grids \\
      --shard-steps-env

For én prosess (ingen sharding, én fil):
  python sorted_h5_all.py \\
      --steps-dir  CVs/200 \\
      --out        CVs/200/sorted/mat_all.h5 \\
      --all-grids
"""

from __future__ import annotations
from pathlib import Path
import argparse
import numpy as np
import h5py
import re
from typing import List, Dict, Tuple, Optional, Sequence
import os

# ----------------- helpers -----------------

STEP_RE = re.compile(r"step_(\d+)\.h5$")


def get_rank_world_from_env() -> tuple[int, int]:
    """Return (rank, world_size) from Slurm/MPI env, default to (0,1)."""
    r = int(os.getenv("SLURM_PROCID", os.getenv("PMI_RANK", "0")))
    w = int(os.getenv("SLURM_NTASKS", os.getenv("WORLD_SIZE", "1")))
    return r, w


def shard_list(items, rank: int, world: int, mode: str = "stride"):
    items = list(items)
    if world <= 1:
        return items
    if mode == "block":
        n = len(items)
        b = (n + world - 1) // world
        lo, hi = rank * b, min((rank + 1) * b, n)
        return items[lo:hi]
    # default: stride
    return items[rank::world]


def is_valid_h5(path: Path) -> bool:
    """Cheap precheck + open test: returns True only if file is readable HDF5."""
    try:
        if not h5py.is_hdf5(path):
            return False
        with h5py.File(path, "r") as f:
            _ = list(f.keys())
        return True
    except Exception:
        return False


def validate_step_files(steps: list[Path]) -> tuple[list[Path], list[Path]]:
    """Split into (valid, bad) by attempting to open each file safely."""
    good, bad = [], []
    for p in steps:
        if is_valid_h5(p):
            good.append(p)
        else:
            bad.append(p)
    return good, bad


def discover_step_files(steps_dir: Path) -> List[Path]:
    steps = sorted(p for p in steps_dir.glob("step_*.h5") if STEP_RE.search(p.name))
    if not steps:
        raise FileNotFoundError(f"No step_*.h5 found in {steps_dir}")
    return steps


def discover_first_step_with_grid(steps: List[Path], grid_id: int) -> Optional[Path]:
    """Find the first step file that has group /<grid_id>/."""
    for p in steps:
        try:
            with h5py.File(p, "r") as f:
                if str(grid_id) in f:
                    return p
        except Exception:
            pass
    return None


def discover_all_grids(steps: List[Path]) -> List[int]:
    """Union av alle numeriske top-level groups (grid IDs) over alle step-filer."""
    grids = set()
    for p in steps:
        try:
            with h5py.File(p, "r") as f:
                for k in f.keys():
                    try:
                        grids.add(int(k))
                    except Exception:
                        pass
        except Exception:
            pass
    return sorted(grids)


def discover_modules_for_grid(steps: List[Path], grid_id: int) -> List[str]:
    """
    Finn alle moduler (gruppe-navn) under /<grid_id>/ i første step-fil som
    faktisk har denne grid-gruppen.

    Vi ekskluderer:
      - "pair_dist_all_atoms"  (brukes kun for 'standard' hvis --include-standard)
      - "neighbor_all"         (lages av dette scriptet)
      - "standard"             (bare i ferdig aggregert fil)
    """
    first = discover_first_step_with_grid(steps, grid_id)
    if first is None:
        return []

    exclude = {"pair_dist_all_atoms", "neighbor_all", "standard"}

    with h5py.File(first, "r") as f:
        g = f[str(grid_id)]
        mods = [k for k in g.keys() if k not in exclude]

    mods = sorted(mods)
    return mods


def step_has_group(step: Path, grid_id: int, module: str) -> bool:
    gpath = f"{grid_id}/{module}"
    try:
        with h5py.File(step, "r") as f:
            return gpath in f
    except Exception:
        return False


def to_py_str_list(a: np.ndarray) -> List[str]:
    out: List[str] = []
    for x in a:
        if isinstance(x, (bytes, bytearray)):
            out.append(x.decode("utf-8"))
        else:
            out.append(str(x))
    return out


def to_sbytes(a: Sequence[str]) -> np.ndarray:
    return np.array([s.encode("utf-8") for s in a], dtype="S")


def parse_step_id(p: Path) -> int:
    m = STEP_RE.search(p.name)
    if not m:
        raise ValueError(f"Bad step filename: {p.name}")
    return int(m.group(1))


def read_labels_for_module(step: Path, grid_id: int, module: str) -> List[str]:
    with h5py.File(step, "r") as f:
        g = f[f"{grid_id}/{module}"]
        if "labels" not in g:
            raise KeyError(f"{step}:{grid_id}/{module} has no 'labels'")
        return to_py_str_list(g["labels"][()])


def read_values_for_module(step: Path, grid_id: int, module: str) -> np.ndarray:
    with h5py.File(step, "r") as f:
        g = f[f"{grid_id}/{module}"]
        if "values" not in g:
            raise KeyError(f"{step}:{grid_id}/{module} has no 'values'")
        vals = g["values"][()]
        if vals.ndim != 2 or vals.shape[0] != 1:
            vals = vals[:1, :]
        return vals[0]


def ensure_labels_consistent(
    steps: List[Path], grid_id: int, module: str, ref_labels: List[str]
) -> None:
    for p in steps:
        labs = read_labels_for_module(p, grid_id, module)
        if labs != ref_labels:
            raise ValueError(
                f"Label mismatch for module '{module}' in {p}.\n"
                f"Expected {ref_labels[:8]}..., got {labs[:8]}..."
            )


def prefix_for_module(mod: str) -> str:
    """
    Kolonne-prefiks for et gitt modulnavn. Bruker kortere alias for noen,
    ellers bare modulnavnet selv.
    """
    mapping = {
        # gamle neighbor-moduler
        "neighbor_wannier_ranked": "wannier",
        "neighbor_forces_projection": "forces",
        "neighbor_mulliken_ranked": "mulliken",
        "neighbor_pt_geometry_ranked": "ptgeom",
        "neighbor_OO_ranked": "OO",
        "neighbor_OH_ranked": "OH",
        "neighbor_OH_orientation_ed": "OHed",
        "neighbor_HOH_angle_ranked": "HOH",
        "neighbor_IonO_ranked": "IonO",
        "hb_wire_length": "hb",
        "pair_dist_all_atoms": "pairdist",
        # du kan legge til egne alias her om du vil:
        # "wire_compression": "wireC",
        # "zundel_coordinate": "zundel",
        # osv...
    }
    return mapping.get(mod, mod)


def build_lambda_and_weight(steps: List[Path]) -> Tuple[np.ndarray, np.ndarray]:
    data = []
    skipped = 0
    for p in steps:
        try:
            step_id = parse_step_id(p)
            with h5py.File(p, "r") as f:
                lam = float(f.attrs.get("lambda_max", np.nan))
                w = float(f.attrs.get("weight", np.nan))
            data.append((step_id, lam, w))
        except Exception:
            skipped += 1
            continue
    if skipped:
        print(f"[warn] lambda_and_weight: skipped {skipped} bad files.")

    data.sort(key=lambda x: x[0])
    arr = np.array(data, dtype=np.float64)
    labels = np.array(["RETIS_step", "lambda_max", "weight"], dtype=object)
    return arr, labels


def write_group(
    outf: h5py.File,
    grid_id: int,
    name: str,
    cv: np.ndarray,
    cols: List[str],
    float_dtype: str = "f4",
) -> None:
    gpath = f"{grid_id}/{name}"
    if gpath in outf:
        del outf[gpath]
    g = outf.create_group(gpath)
    cv = np.asarray(cv, dtype=np.dtype(float_dtype))
    g.create_dataset("cv", data=cv, compression="gzip", shuffle=True)
    g.create_dataset("cols", data=to_sbytes(cols), compression="gzip", shuffle=True)


def aggregate_module_matrix(
    steps: List[Path], grid_id: int, module: str, float_dtype: str = "f4"
) -> Tuple[np.ndarray, List[str]]:
    ref_labels = read_labels_for_module(steps[0], grid_id, module)
    ensure_labels_consistent(steps, grid_id, module, ref_labels)

    prefix = prefix_for_module(module)
    cols = ["RETIS_step"] + [f"{prefix}::{lab}" for lab in ref_labels]

    rows = []
    for p in steps:
        sid = parse_step_id(p)
        vals = read_values_for_module(p, grid_id, module)
        rows.append(np.concatenate([[sid], vals.astype(np.float64)], axis=0))

    rows.sort(key=lambda r: r[0])
    mat = np.vstack(rows).astype(np.float64, copy=False)
    return mat, cols


def aggregate_standard(steps: List[Path], grid_id: int) -> Tuple[np.ndarray, List[str]]:
    module = "pair_dist_all_atoms"
    ref_labels = read_labels_for_module(steps[0], grid_id, module)
    ensure_labels_consistent(steps, grid_id, module, ref_labels)
    cols = ["RETIS_step"] + ref_labels
    rows = []
    for p in steps:
        sid = parse_step_id(p)
        vals = read_values_for_module(p, grid_id, module)
        rows.append(np.concatenate([[sid], vals.astype(np.float64)], axis=0))
    rows.sort(key=lambda r: r[0])
    mat = np.vstack(rows).astype(np.float64, copy=False)
    return mat, cols


def concatenate_modules(
    mats_and_cols: List[Tuple[np.ndarray, List[str]]]
) -> Tuple[np.ndarray, List[str]]:
    """
    Horisontal concat. Første kolonne i alle matriser er RETIS_step,
    og antas å ha samme rekkefølge i alle moduler.
    """
    if not mats_and_cols:
        raise ValueError("No module matrices to concatenate")

    base_mat, base_cols = mats_and_cols[0]
    retis = base_mat[:, 0:1]
    all_cols = base_cols[:]
    all_feats = [base_mat[:, 1:]]

    for mat, cols in mats_and_cols[1:]:
        if not np.array_equal(mat[:, 0], base_mat[:, 0]):
            raise ValueError(
                "RETIS_step ordering mismatch between modules; please check inputs"
            )
        all_feats.append(mat[:, 1:])
        all_cols.extend(cols[1:])

    full = np.concatenate([retis] + all_feats, axis=1)
    return full, all_cols


def copy_root_attrs(outf: h5py.File, attrs: Dict[str, float]) -> None:
    for k, v in attrs.items():
        outf.attrs[k] = v


# ----------------- main -----------------

def main():
    ap = argparse.ArgumentParser(
        description="Aggregate CV modules into sorted H5 (optionally step-sharded)."
    )
    ap.add_argument(
        "--steps-dir", type=Path, required=True, help="Directory with step_*.h5 files"
    )
    ap.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Base output H5 file (final name or part prefix). Parts are <out>.part.<rank>.h5",
    )

    # grid selection
    ap.add_argument("--grid-id", type=int, help="Single grid id to aggregate (e.g., 100)")
    ap.add_argument(
        "--grid-ids", nargs="*", type=int, help="Multiple grid ids (e.g., 0 5 10 ... 495)"
    )
    ap.add_argument(
        "--grid-range",
        nargs=3,
        type=int,
        metavar=("START", "STOP", "STEP"),
        help="Inclusive range of grid ids (e.g., 0 495 5)",
    )
    ap.add_argument(
        "--all-grids",
        action="store_true",
        help="Aggregate all numeric grids found in step files (default if none given)",
    )

    # modules / options
    ap.add_argument(
        "--modules",
        nargs="*",
        default=None,
        help=(
            "Explicit module names under /<grid>/... "
            "If omitted, auto-discover all groups except 'pair_dist_all_atoms', 'neighbor_all', 'standard'."
        ),
    )
    ap.add_argument(
        "--include-standard",
        action="store_true",
        help="Also build /<grid>/standard from pair_dist_all_atoms (if present)",
    )
    ap.add_argument(
        "--dtype",
        default="f4",
        choices=["f4", "f8"],
        help="Float dtype for cv matrices",
    )

    # parallelism: shard by steps (optional)
    ap.add_argument(
        "--shard-steps-env",
        action="store_true",
        help="Shard step_*.h5 across ranks using SLURM_PROCID/SLURM_NTASKS",
    )
    ap.add_argument(
        "--shard-mode", choices=["stride", "block"], default="stride"
    )

    # resilience
    ap.add_argument(
        "--resume",
        action="store_true",
        help="If this rank's part file exists, skip writing it",
    )
    ap.add_argument(
        "--force-overwrite",
        action="store_true",
        help="Overwrite this rank's part file even if it exists",
    )

    args = ap.parse_args()

    # 1) Step files
    steps = discover_step_files(args.steps_dir)
    steps, bad = validate_step_files(steps)
    if bad:
        print(f"[warn] Skipping {len(bad)} unreadable step files (first 3 shown):")
        for p in bad[:3]:
            print(f"       - {p}")
    if not steps:
        raise RuntimeError("No readable step_*.h5 files found after validation.")

    # 2) Grid selection
    if args.grid_ids:
        grid_ids = sorted(set(args.grid_ids))
    elif args.grid_range:
        s, e, st = args.grid_range
        grid_ids = list(range(s, e + 1, st))
    elif args.all_grids or (args.grid_id is None):
        grid_ids = discover_all_grids(steps)
        if not grid_ids:
            raise RuntimeError("No numeric grid groups found in any step file.")
    else:
        grid_ids = [args.grid_id]

    # 3) Rank & sharding
    if args.shard_steps_env:
        rank, world = get_rank_world_from_env()
    else:
        rank, world = 0, 1

    my_steps = shard_list(steps, rank, world, mode=args.shard_mode)
    print(f"[rank {rank}/{world}] taking {len(my_steps)} of {len(steps)} steps.")

    if not my_steps:
        print(f"[rank {rank}] no steps assigned → exiting cleanly.")
        return

    # 4) Part filenames
    part_path = Path(f"{args.out}.part.{rank}.h5")
    tmp_path = Path(f"{part_path}.tmp.{os.getpid():x}")
    part_path.parent.mkdir(parents=True, exist_ok=True)

    if part_path.exists() and args.resume and not args.force_overwrite:
        print(f"[rank {rank}] part exists → resume skip: {part_path}")
        return

    # 5) Shared root attrs
    with h5py.File(steps[0], "r") as f0:
        shared_attrs = {
            k: f0.attrs[k]
            for k in ("wham_ngrid", "cell_size", "n_atoms")
            if k in f0.attrs
        }

    # 6) Write tmp file, then atomic rename
    try:
        with h5py.File(tmp_path, "w") as outf:
            copy_root_attrs(outf, shared_attrs)

            lamw, lamw_labels = build_lambda_and_weight(my_steps)
            d = outf.create_dataset(
                "lambda_and_weight", data=lamw, compression="gzip", shuffle=True
            )
            d.attrs["labels"] = lamw_labels

            for gid in grid_ids:
                # Hvilke moduler for denne griden?
                mods = args.modules or discover_modules_for_grid(steps, gid)
                if not mods:
                    print(f"[rank {rank}] [skip] grid {gid}: no modules")
                    continue

                mats_and_cols = []

                for mod in mods:
                    eligible = [p for p in my_steps if step_has_group(p, gid, mod)]
                    if not eligible:
                        continue

                    ref_labels = read_labels_for_module(eligible[0], gid, mod)
                    ensure_labels_consistent(eligible, gid, mod, ref_labels)

                    mat, cols = aggregate_module_matrix(
                        eligible, gid, mod, float_dtype=args.dtype
                    )
                    write_group(outf, gid, mod, mat, cols, float_dtype=args.dtype)
                    mats_and_cols.append((mat, cols))

                if mats_and_cols:
                    full, full_cols = concatenate_modules(mats_and_cols)
                    write_group(
                        outf, gid, "neighbor_all", full, full_cols, float_dtype=args.dtype
                    )

                if args.include_standard:
                    try:
                        eligible = [
                            p
                            for p in my_steps
                            if step_has_group(p, gid, "pair_dist_all_atoms")
                        ]
                        if eligible:
                            std_mat, std_cols = aggregate_standard(eligible, gid)
                            write_group(
                                outf, gid, "standard", std_mat, std_cols, float_dtype=args.dtype
                            )
                    except Exception as e:
                        print(
                            f"[rank {rank}] [warn] grid {gid}: standard aggregation skipped ({e})"
                        )

        os.replace(tmp_path, part_path)
        print(f"[rank {rank}] wrote {part_path}")

    finally:
        if tmp_path.exists():
            try:
                os.remove(tmp_path)
            except Exception:
                pass


if __name__ == "__main__":
    main()
