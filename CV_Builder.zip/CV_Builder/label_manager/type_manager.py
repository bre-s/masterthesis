# type_manager.py (minimal edits)
#from pyRETIS import build_all_molecule_labels
from glob import iglob
from typing import Dict, List
import numpy as np
import pandas as pd
from ase.io import read as ase_read
from ase import Atoms


class TypeManager:
    def __init__(self, CVs, cv_types: set[str], load_dir):
        self.config = CVs
        self.cv_types = cv_types
        self.sort_idx: np.ndarray = np.array([])
        self.labels: Dict[str, np.ndarray] = {}
        self.attributes: Dict[str, Dict[str, List[str]]] = {}
        self.filter_idx: Dict[str, np.ndarray] = {}
        self.pairs: Dict[str, np.ndarray] = {}        # NEW: numeric index pairs
        self.names_ref: np.ndarray | None = None      # NEW: canonical names per position
        self.df_sorted_reference: pd.DataFrame | None = None  # NEW
        self.load_dir = load_dir #load_directory

        # Step 1: Load & sort atoms once (this defines the REFERENCE order + names)
        traj_file = self._find_first_xyz(self.load_dir)
        df_sorted = self._load_and_sort_atoms(traj_file)
        self.df_sorted_reference = df_sorted.copy()

        # IMPORTANT: sort_idx should be the reference order by original indices
        # Keep the 'orig_idx' column *from the reference frame* in sorted order:
        self.sort_idx = df_sorted['orig_idx'].to_numpy()   # <= not df_sorted.index!

        # Canonical names for readability (stick with your current H64 style)
        self.names_ref = np.array(
            [f"{el}{i}" for el, i in zip(df_sorted['element'], df_sorted['orig_idx'])]
        )

        # Step 2: Add support for each requested type
        if "all_atoms" in cv_types:
            self._build_all_atoms(df_sorted)

        if "index_invariant" in cv_types:
            # kept as placeholder; invariance is handled by your IndexInvariantMapper.  TODO: remove later if not implemented here
            self._build_index_invariant(df_sorted)

    def _find_first_xyz(self, paths) -> str:
        for path in iglob(f"{paths}/*/accepted/*traj*.xyz"):
            if "-frc-" not in path:
                return path
        raise FileNotFoundError(f"No valid .xyz file found under {paths}/*/accepted")

    def _load_and_sort_atoms(self, xyz_path: str) -> pd.DataFrame:   #TODO: can insert so index="phasepoint under investigation"
        atoms = ase_read(xyz_path, index=0)
        assert isinstance(atoms, Atoms)

        elements = atoms.get_chemical_symbols()
        pos = atoms.get_positions()
        df = pd.DataFrame({
            'element': elements,
            'orig_idx': list(range(len(elements))),
            'x': pos[:, 0],
            'y': pos[:, 1],
            'z': pos[:, 2],
        })
        # This is your REFERENCE sort rule
        return df.sort_values(by=["element", "orig_idx"], kind="mergesort").reset_index(drop=True)

    def _build_all_atoms(self, df_sorted: pd.DataFrame):
        names = self.names_ref
        if names is None:
            raise ValueError("self.names_ref is not initialized")
        n = len(names)

        # Numeric pairs for fast math:
        pairs = np.array([(i, j) for i in range(n) for j in range(i+1, n)], dtype=int)
        self.pairs["all_atoms"] = pairs

        # Human-readable labels (reference order):
        labels = np.array([f"{names[i]}-{names[j]}" for i, j in pairs])
        self.labels["all_atoms"] = labels

        self.attributes["all_atoms"] = {}
        self.filter_idx["all_atoms"] = np.arange(len(labels))

    def _build_index_invariant(self, df_sorted: pd.DataFrame):
        pass  # invariance handled by permutation in your loop
