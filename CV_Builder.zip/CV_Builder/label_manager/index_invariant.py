# index_invariant.py
from __future__ import annotations
import numpy as np

try:
    from scipy.optimize import linear_sum_assignment
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False

PHI = (1.0 + 5.0 ** 0.5) / 2.0
U_BREAK = np.array([1.0, PHI, PHI**2], dtype=float)
U_BREAK /= np.linalg.norm(U_BREAK)


def _pbc_delta(delta: np.ndarray, L: float | None) -> np.ndarray:
    """Apply minimum-image convention to vector(s) `delta` given box length L."""
    if L is None:
        return delta
    return delta - L * np.round(delta / L)


def _pbc_cost(P: np.ndarray, Q: np.ndarray, L: float | None) -> np.ndarray:
    """
    Pairwise squared distances with PBC between point sets P (n,3) and Q (m,3).
    Returns (n, m) cost matrix = |P_i - Q_j|^2 (min-image).
    """
    d = P[:, None, :] - Q[None, :, :]          # (n,m,3)
    d = _pbc_delta(d, L)
    return np.sum(d * d, axis=2)


def _kabsch(P: np.ndarray, Q: np.ndarray) -> np.ndarray:
    """Kabsch rotation (no translation). P,Q must be centered (n,3). Returns 3x3 R."""
    H = P.T @ Q
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0.0:
        Vt[-1, :] *= -1.0
        R = Vt.T @ U.T
    return R


def _greedy_assign(cost: np.ndarray) -> np.ndarray:
    """Greedy row-wise unique assignment; returns array j for each row i."""
    N = cost.shape[0]
    assigned_j = set()
    rows = np.arange(N)
    cols = np.argmin(cost, axis=1)
    order = np.argsort(cost[np.arange(N), cols])
    rows = rows[order]
    cols = cols[order]
    assign = -np.ones(N, dtype=int)
    for i, j in zip(rows, cols):
        if j not in assigned_j:
            assign[i] = j
            assigned_j.add(j)
    # fill leftovers if any (rare)
    remaining_i = np.where(assign < 0)[0]
    remaining_j = [j for j in range(cost.shape[1]) if j not in assigned_j]
    for i, j in zip(remaining_i, remaining_j):
        assign[i] = j
    return assign


def _two_nearest_h_for_oxygen_pbc(O_pos: np.ndarray, H_pos: np.ndarray, L: float | None, k: int = 2) -> np.ndarray:
    """For each O (nO,3), return indices of k nearest H (nH,3) under PBC; (nO,k)."""
    d = O_pos[:, None, :] - H_pos[None, :, :]
    d = _pbc_delta(d, L)
    d2 = np.sum(d * d, axis=2)
    return np.argsort(d2, axis=1)[:, :k]


def _order_two_h_deterministically(O_pos: np.ndarray, H_pair: np.ndarray, L: float | None) -> tuple[np.ndarray, np.ndarray]:
    """
    Deterministically order 2 H around O via projection onto U_BREAK.
    Returns:
      order_idx: indices (len 2) into H_pair for (H1,H2)
      d2: squared OH distances (len 2) for cutoff checks
    """
    OH = _pbc_delta(H_pair - O_pos[None, :], L)   # (2,3)
    proj = OH @ U_BREAK
    order = np.argsort(proj)                      # [low, high]
    order = order[::-1]                           # (H1,H2)
    d2 = np.sum(OH * OH, axis=1)
    return order, d2


class IndexInvariantMapper:
    """
    Map each frame's sorted-atom order to a fixed REFERENCE order.

    - Works with arbitrary sort (H first or O first). We DO NOT assume O-block first.
    - Oxygens are matched to reference O via ICP (+ PBC min-image) and optimal assignment.
    - Hydrogens are attached per O: for each reference O, we take the 2 nearest H in the
        *reference* and store their H-list indices (ordered deterministically). For each
        current frame we do the same around the matched current O and map pairwise in that order.
    - The returned `perm` lets you do: coords_invariant = coords_sorted[perm],
        so positions line up with your reference’s human-readable labels.

    Expected df_sorted columns: ['element','orig_idx','x','y','z'].
    """

    def __init__(
        self,
        cutoff: float = 1.2,
        max_iter: int = 7,
        err_thresh: float = 4.0,     # Å^2 (RMSD ≈ 2 Å)
        box: float | None = None,
        prefer_hungarian: bool = True,
    ):
        self.cutoff = float(cutoff)
        self.max_iter = int(max_iter)
        self.err_thresh = float(err_thresh)
        self.box = float(box) if box is not None else None
        self.prefer_hungarian = bool(prefer_hungarian)

        # reference data
        self.has_reference = False
        self.O_ref: np.ndarray | None = None
        self.H_ref: np.ndarray | None = None
        self.idx_O_ref: np.ndarray | None = None  # absolute indices in reference df_sorted
        self.idx_H_ref: np.ndarray | None = None
        self.ref_H_pairs_per_O: np.ndarray | None = None  # (nO,2) indices into H_ref list

    # -------------------- internal helpers --------------------

    @staticmethod
    def _split_O_H(df_sorted) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Return (O_pos, H_pos, idx_O_abs, idx_H_abs) from df_sorted."""
        elements = df_sorted['element'].to_numpy()
        idx_O = np.flatnonzero(elements == 'O').astype(int)
        idx_H = np.flatnonzero(elements == 'H').astype(int)

        xyz = df_sorted[['x', 'y', 'z']].to_numpy()
        O = xyz[idx_O]
        H = xyz[idx_H]
        return O, H, idx_O, idx_H

    def _icp_match_oxygens(self, O_cur: np.ndarray, O_ref: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
        """
        ICP loop with PBC-aware unwrapping before Kabsch.
        Returns:
        assign  : cur_O_i -> ref_O_j
        R       : 3x3 rotation matrix
        err     : mean squared residual (Å^2) after final alignment
        """
        # Center both sets (rough centering; we will PBC-unwrap pairwise later)
        Pc = O_cur - O_cur.mean(axis=0)
        Qc = O_ref - O_ref.mean(axis=0)

        # Initial assignment (use optimal by default)
        C0 = _pbc_cost(Pc, Qc, self.box)
        if _HAVE_SCIPY and self.prefer_hungarian:
            rows0, cols0 = linear_sum_assignment(C0)
            assign = cols0
        else:
            assign = _greedy_assign(C0)

        R = np.eye(3)
        for _ in range(self.max_iter):
            # Rotate current to provisional orientation
            P_rot = Pc @ R.T                           # (nO,3)

            # --- PBC UNWRAP STEP (critical) ---
            # Bring each rotated point to the nearest image of its matched reference
            # Δ = min-image(P_rot - Qc[assign]);  P_unwrap = Qc[assign] + Δ
            delta = _pbc_delta(P_rot - Qc[assign], self.box)
            P_unwrap = Qc[assign] + delta

            # Re-center the unwrapped pair before Kabsch (robust numerics)
            P_u = P_unwrap - P_unwrap.mean(axis=0)
            Q_u = Qc[assign] - Qc[assign].mean(axis=0)

            # Update rotation
            R = _kabsch(P_u, Q_u)

            # Recompute assignment under new rotation using PBC distances
            P_rot = Pc @ R.T
            C = _pbc_cost(P_rot, Qc, self.box)
            if _HAVE_SCIPY and self.prefer_hungarian:
                rows, cols = linear_sum_assignment(C)
                assign = cols
            else:
                assign = _greedy_assign(C)

        # Final residual (PBC-aware)
        P_final = (O_cur - O_cur.mean(axis=0)) @ R.T
        resid = _pbc_delta(P_final - Qc[assign], self.box)
        err = float(np.mean(np.sum(resid * resid, axis=1)))
        return assign, R, err


    # -------------------- public API --------------------

    def set_reference(self, df_sorted) -> None:
        """
        Define the canonical reference frame: stores O_ref, H_ref and the mapping of
        *reference* O -> its 2 *reference* H indices (ordered deterministically).
        """
        O_ref, H_ref, idx_O_ref, idx_H_ref = self._split_O_H(df_sorted)

        # store
        self.O_ref = O_ref
        self.H_ref = H_ref
        self.idx_O_ref = idx_O_ref
        self.idx_H_ref = idx_H_ref

        # For each ref O, store the indices (into H_ref) of its two nearest H, ordered deterministically
        nn_ref = _two_nearest_h_for_oxygen_pbc(O_ref, H_ref, self.box, k=2)  # (nO,2)
        ordered_pairs = np.empty_like(nn_ref)
        for iO in range(O_ref.shape[0]):
            pair = H_ref[nn_ref[iO]]  # (2,3)
            order, _ = _order_two_h_deterministically(O_ref[iO], pair, self.box)
            ordered_pairs[iO] = nn_ref[iO][order]
        self.ref_H_pairs_per_O = ordered_pairs  # (nO,2)

        self.has_reference = True

    def map_to_reference(self, df_sorted) -> tuple[np.ndarray, float, dict]:
        """
        Map current df_sorted to reference order.
        Returns:
          perm  : (N,) int array so that coords_invariant = coords_sorted[perm]
          err   : mean squared O residual after ICP (Å^2)
          flags : dict with diagnostics (bad_err, bad_counts, bad_h_cutoff)
        """
        assert self.has_reference, "Reference not set. Call set_reference(...) first."
        assert self.O_ref is not None and self.H_ref is not None
        assert self.idx_O_ref is not None and self.idx_H_ref is not None
        assert self.ref_H_pairs_per_O is not None

        O_cur, H_cur, idx_O_cur, idx_H_cur = self._split_O_H(df_sorted)
        nO, nH = O_cur.shape[0], H_cur.shape[0]
        flags = {
            'bad_counts': (2 * nO != nH),
            'bad_err': False,
            'bad_h_cutoff': False,
        }

        # 1) Match O via ICP (+ optimal assignment)
        assign_O, R, err = self._icp_match_oxygens(O_cur, self.O_ref)
        flags['bad_err'] = (err > self.err_thresh)

        # 2) For each current O, find its two nearest H and order deterministically (with PBC)
        nnH_cur = _two_nearest_h_for_oxygen_pbc(O_cur, H_cur, self.box, k=2)  # (nO,2)

        # 3) Build permutation over the FULL atom list (length = N = nO + nH in current frame)
        N = df_sorted.shape[0]
        perm = -np.ones(N, dtype=int)

        # Absolute indices for O/H in reference and current frames:
        idx_O_ref = self.idx_O_ref
        idx_H_ref = self.idx_H_ref
        # Invert the O assignment: ref_O_j -> cur_O_i
        ref_to_curO = np.empty(nO, dtype=int)
        ref_to_curO[assign_O] = np.arange(nO)

        # -- Oxygens: put current O at the *reference* O positions
        for cur_O_i in range(nO):
            ref_O_j = assign_O[cur_O_i]
            abs_dest = int(idx_O_ref[ref_O_j])   # reference absolute index where this O should go
            abs_src  = int(idx_O_cur[cur_O_i])   # current absolute index of this O
            perm[abs_dest] = abs_src

        # -- Hydrogens: per ref-O, map ordered current H pair -> ordered reference H pair
        # Also check cutoff on current OH distances:
        cutoff2 = self.cutoff * self.cutoff
        for ref_O_j in range(nO):
            cur_O_i = int(ref_to_curO[ref_O_j])
            cur_pair_idx_H_list = nnH_cur[cur_O_i]        # indices into H_cur (0..nH-1)
            H_pair_cur = H_cur[cur_pair_idx_H_list]       # (2,3)
            order_cur, d2_cur = _order_two_h_deterministically(O_cur[cur_O_i], H_pair_cur, self.box)
            if np.any(d2_cur > cutoff2):
                flags['bad_h_cutoff'] = True
            cur_ordered_H_list_idx = cur_pair_idx_H_list[order_cur]

            ref_pair_idx_H_list = self.ref_H_pairs_per_O[ref_O_j]  # indices into H_ref (0..nH-1), already ordered

            # place each H into its *reference* absolute index
            for k in range(2):
                abs_dest = int(idx_H_ref[ref_pair_idx_H_list[k]])  # reference absolute index for this H
                abs_src  = int(idx_H_cur[cur_ordered_H_list_idx[k]])  # current absolute index of this H
                perm[abs_dest] = abs_src

        # 4) Sanity: fill any leftover positions trivially (shouldn't happen unless counts mismatch)
        if np.any(perm < 0):
            leftovers_dest = np.where(perm < 0)[0]
            # try to fill with unassigned current indices
            assigned_src = set(perm[perm >= 0].tolist())
            all_src = set(range(N))
            leftovers_src = list(all_src - assigned_src)
            for d, s in zip(leftovers_dest, leftovers_src):
                perm[d] = s

        return perm, err, flags
    
    def label_waters_O2H(self, df_sorted, k: int | None = None, lam: float = 0.2):
        """
        Build labels 'Hxx-Hyy-Ozz' using the SAME selection + ordering as the mapper.
        If k is None -> use exact same 'nearest-2' path as in map_to_reference.
        If k is an int  -> use 2-of-k selection (prefers good HOH angle), then deterministic order.
        """
        import numpy as np

        elements = df_sorted['element'].to_numpy()
        idx_O = np.flatnonzero(elements == 'O')
        idx_H = np.flatnonzero(elements == 'H')
        xyz   = df_sorted[['x','y','z']].to_numpy()

        O = xyz[idx_O]
        H = xyz[idx_H]

        # Names come from df_sorted['orig_idx'] (so: current naming or reference naming,
        # depending on which DF you pass in)
        H_names = np.array([f"H{int(i)}" for i in df_sorted.loc[idx_H, 'orig_idx'].to_numpy()])
        O_names = np.array([f"O{int(i)}" for i in df_sorted.loc[idx_O, 'orig_idx'].to_numpy()])

        labels = []
        if k is None:
            # --- EXACTLY the same rule as mapper (nearest-2 + deterministic order) ---
            nnH = _two_nearest_h_for_oxygen_pbc(O, H, self.box, k=2)  # (nO,2) indices into H
            for o_i in range(len(idx_O)):
                pair_idx = nnH[o_i]
                H_pair   = H[pair_idx]
                order, _ = _order_two_h_deterministically(O[o_i], H_pair, self.box)
                h1, h2   = pair_idx[order]
                labels.append(f"{H_names[h1]}-{H_names[h2]}-{O_names[o_i]}")
        else:
            # --- 2-of-k variant (more robust near stretched bonds); still deterministic order ---
            for o_i in range(len(idx_O)):
                pair_idx, _ = _choose_two_h_for_oxygen(O[o_i], H, self.box, k=k, theta0=np.deg2rad(104.5), lam=lam)
                h1, h2 = pair_idx.tolist()
                labels.append(f"{H_names[h1]}-{H_names[h2]}-{O_names[o_i]}")

        return labels



