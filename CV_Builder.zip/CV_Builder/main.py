import logging
import argparse
import time
from pathlib import Path

#Program imports
from builder import build_app


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument(
        '--toml', default=Path('infretis.toml'), type=Path,
        help='Path to your .toml settings'
    )
    p.add_argument(
        '--load-dir',
        default=Path('../load'), type=Path,
        help='Directory where input files are located'
    )
    p.add_argument(
        '--data',
        default=Path('../infretis_data.txt'), type=Path, 
        help='Path to infretis data file. Used for wham calculations.'
    )
    p.add_argument(
    '--output-dir',
    default=Path('CVs'), type=Path,
    help='Directory where output files will be saved'
    )
    p.add_argument(
        '--grid-mode',
        choices=['selection', 'range'],
        default='selection',
        help=(
            "How to pick which grid‐indices to analyze:\n"
            "  • selection: use settings['wham']['selection']\n"
            "  • range:     use settings['wham']['start_grid'], "
            "settings['wham']['end_grid'], settings['wham']['step_size']")
    )
    p.add_argument(
        '--approximate-threshold',
        type=float,
        default=1e-5,  # After testing, set this to 0 to disable approximation
        help=(
            "If lamres ≤ this value, multiply lamres by --approximate-factor. "
            "(Set to 0 to disable.)"
        )
    )
    p.add_argument(
        '--approximate-factor',
        type=float,
        default=100.0, #oppadert Wham til å bruke approximate-factoor som øvre grense -> lamres blir aldri større en korteste grensesnitt
        help="Multiply lamres by this factor when lamres ≤ --approximate-threshold."
    )
    p.add_argument(
        '--cv-measure', nargs='*',
        type=str,
        default=None,
        help='Specify CV measure. Inserting no value will select CVs from the TOML file, i.e [cv_matrix][measure]= List[str].'
    )
    p.add_argument(
    '--cv_type', nargs='*', type=str,
    default=None,
    help='Override the [cv_matrix.*].type settings. Provide space-separated types, e.g., --cv_type all_atoms index_invariant'
)
    p.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Set the logging level for stdout messages.'
    )
    p.add_argument(
        '--overwrite',
        action='store_true',
        help='Delete any previous output before running new analysis.'
    )   
    p.add_argument(
        '--resume',
        action='store_true',
        help='Resume from previous run (skip already completed work).'
    )

    return p.parse_args()

def main():
    start_time = time.perf_counter()
    try:
        args = parse_args()
        # TODO: Add validation for args.toml, args.load_dir, and args.data here, now they are validated in the builder.py
        logging.basicConfig(level=getattr(logging, args.log_level.upper()),
                            format="%(levelname)s:%(name)s:%(message)s")

        runner = build_app(args)
        runner.run()
    except Exception as e:
        logging.error(f"A fatal error occurred: {e}", exc_info=True)
    finally:
        end_time = time.perf_counter()
        print(f'Total computation time: {end_time - start_time:.2f} seconds')



if __name__ == '__main__':
    main()
