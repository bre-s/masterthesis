from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, List, Optional, Union
import toml, os, glob, sys
import numpy as np

from wham_weights import TrajWeights  # type: ignore 
from simmulationrunner import SimulationRunner 


#grid = GridDefinition.from_wham_settings(wham)     # frozen grid

def build_app(args):
    """
    Build application based on the provided command-line arguments
    """
    paths = Paths.from_args(args)                           # Load paths from command-line arguments
    config = load_config(args.toml)                         # Load configuration from TOML file
    interfaces = SimSettings.from_dict(config['simulation'])  # Extract interfaces from the config
    wham = WhamSettings.from_dict(config['wham'])           # Extract WHAM settings from the config
    pred_power = PredictivePowerSettings.from_dict(config['predictive_power'])  # Extract predictive power settings from the config
    CVs = CVMatrixSettings.from_dict(config['cv_matrix'])  # Extract CV matrix settings from the config
    grid = GridDefinition.from_wham_settings(args, wham, interfaces.interfaces)  # Get grid indices and points from WHAM settings


    # TODO: What is the difference between measure and type design?
    toml_measure = config['cv_matrix'].get('measure', [])
    if args.cv_measure:
        invalid = [cv for cv in args.cv_measure if cv not in toml_measure]
        if invalid:
            raise KeyError(f"CV types not found in TOML: {invalid}")
        CVs = replace(CVs, measure=args.cv_measure)

    #collect all types across all CVs
    all_types = set()
    for measure in CVs.measure:
        measure_block = config["cv_matrix"][measure]
        all_types.update(measure_block.get("type", []))
        print(f"Collected types for {measure}: {measure_block.get('type', [])}")
    if args.cv_type:
        invalid = [t for t in args.cv_type if t not in all_types]
        if invalid:
            raise KeyError(f"Type(s) not found in TOML: {invalid}")
        all_types = set(args.cv_type)  # Override with command-line types if provided


    raw_steps = find_retis_steps(paths.load_dir)            # Find all RETIS steps in the load directory
    print(f"[steps] found {len(raw_steps)} step dirs. first10={raw_steps[:10]}")
    nskip = getattr(wham, 'nskip', 0)    

    # burn-in
    raw_steps = drop_burn_in(
        raw_steps,
        frac=nskip if (isinstance(nskip, (int, float)) and 0 < nskip < 1) else None,
        n=int(nskip) if (isinstance(nskip, (int, float)) and nskip >= 1) else None,
    )

    # shard (return strings; do NOT cast to int)
    rank, world = get_shard_from_env()
    raw_steps = shard_steps(raw_steps, rank, world, mode="stride")

    # build weights with strings
    weights = TrajWeights.from_inputs(
        raw_steps=raw_steps,  # <-- strings
        load_dir=paths.load_dir,
        interfaces=interfaces.interfaces,
        data_file=paths.data_file,
        approximate_threshold=args.approximate_threshold,
        approximate_factor=args.approximate_factor
    )

    #weights.retis_steps = [int(s) for s in raw_steps]

    runner = SimulationRunner(paths, config, interfaces.interfaces, wham, grid, pred_power, CVs, all_types, weights)
    return runner

"""
------------------------------------------------------------------------
Helper functions
------------------------------------------------------------------------
"""

def find_retis_steps(load_dir: Path) -> list[str]:
    # numeric sort: "2" before "10"
    dirs = [
        os.path.basename(d)
        for d in glob.glob(str(load_dir / "*"))
        if os.path.isdir(d) and os.path.basename(d).isdigit()
    ]
    return sorted(dirs, key=lambda s: int(s))

def get_shard_from_env() -> tuple[int, int]:
    """
    Detect Slurm rank / world size. Falls back to a single shard.
    Supports both srun multi-task (SLURM_PROCID/SLURM_NTASKS) and PMI envs.
    """
    rank = int(os.environ.get("SLURM_PROCID",
              os.environ.get("PMI_RANK", "0")))
    world = int(os.environ.get("SLURM_NTASKS",
               os.environ.get("PMI_SIZE", "1")))
    return rank, world

def shard_steps(steps: list[str], rank: int, world: int, mode: str = "stride") -> list[str]:
    if world <= 1:
        return steps
    if mode == "stride":
        # better load balance: 0, world, 2*world, ...
        return steps[rank::world]
    # contiguous block (alternative)
    n = len(steps)
    start = (n * rank) // world
    end   = (n * (rank + 1)) // world
    return steps[start:end]

def drop_burn_in(seq, *, frac: float | None = None, n: int | None = None):
    total = len(seq)
    if n is None:
        n = int(round((frac or 0.0) * total))
    n = max(0, min(n, total))
    return seq[n:]

def load_config(path) -> dict:
    with open(path) as f:
        return toml.load(f)

# Example:
# raw_steps = drop_burn_in(raw_steps, frac=0.05)         # 5%
# raw_steps = drop_burn_in(raw_steps, n=495)             # exactly 495

    



#TODO: could be moved to a separate file, e.g., config.py
"""
------------------------------------------------------------------------
Dataclasses
------------------------------------------------------------------------
"""
@dataclass(frozen=True)
class Paths:
    load_dir: Path     # Directory where trajectory files are located
    data_file: Path    # Path to infretis data file
    toml_file: Path    # Path to the TOML settings file
    output_dir: Path   # Directory where output files will be saved

    @classmethod
    def from_args(cls, args):
        try:
            load = Path(args.load_dir).resolve(strict=True)
            data = Path(args.data).resolve(strict=True)
            toml_path = Path(args.toml).resolve(strict=True)
        except FileNotFoundError as e:
            raise FileNotFoundError(f"File/directory does not exist: {e.args[0]}")

        out = Path(args.output_dir).resolve()

        return cls(load_dir=load, data_file=data, toml_file=toml_path, output_dir=out)
    
@dataclass(frozen=True)
class CVMatrixSettings:
    measure: List[str]         # e.g., ["distance", "angle", "wannier"]
    periodic: bool
    cell_size: float
    engine: str = "cp2k.xyz"   # Optional with default fallback
    molecule_size: int = 3  # Default to 3 if not specified

    @classmethod
    def from_dict(cls, block: Dict) -> 'CVMatrixSettings':
        try:
            return cls(     
                measure=block["measure"],
                periodic=block["periodic"],
                cell_size=block["cell_size"],
                engine=block.get("engine", "cp2k.xyz"),  # fallback if not defined – Only support cp2k.xyz for now
                molecule_size=block.get("molecule_size", 3)  # Default to 3 if not specified
            )
        except KeyError as e:
            raise KeyError(f"[cv_matrix] block is missing required key: {e.args[0]}")

@dataclass(frozen=True)
class WhamSettings:
    n_grid: int
    selection: List[float]
    start_grid: int
    end_grid: int
    step_size: int
    nskip: Union[int, float] = 0

    @classmethod
    def from_dict(cls, block: Dict) -> 'WhamSettings':
        try:
            return cls(
                n_grid=block["n_grid"],
                selection=block["selection"],
                start_grid=block["start_grid"],
                end_grid=block["end_grid"],
                step_size=block["step_size"],
                nskip=block.get("nskip", 0)
            )
        except KeyError as e:
            raise KeyError(f'[wham] block is missing a required key: {e.args[0]}')
            
@dataclass(frozen=True)
class SimSettings:
    interfaces: List[float]

    @classmethod
    def from_dict(cls, block: dict) -> 'SimSettings':
        try:
            return cls(interfaces=block['interfaces'])
        except KeyError as e:
            raise KeyError(f"[simulation] block is missing required key: {e.args[0]}")

@dataclass(frozen=True)
class GridDefinition:
    #TODO: see build_app for comments on this
    grid_idx: np.ndarray
    grid_pts: np.ndarray

    @classmethod
    def from_wham_settings(cls, args, wham: WhamSettings, interfaces: List[float]) -> 'GridDefinition':
        n_grid = int(wham.n_grid)
        full_grid = np.linspace(min(interfaces), max(interfaces), n_grid)
        all_indices = np.arange(n_grid)

        mode = args.grid_mode  # FIXED: use underscore

        if mode == 'selection':
            if not wham.selection:
                raise KeyError("grid_mode='selection' but 'selection' is empty or missing.")
            grid_idx = np.array(wham.selection, dtype=int)

        elif mode == 'range':
            start = int(wham.start_grid)
            end = int(wham.end_grid)
            step = int(wham.step_size)
            grid_idx = all_indices[start:end:step]

        else:
            raise ValueError(f"Unknown grid_mode '{mode}'.")

        grid_idx = np.clip(grid_idx, 0, n_grid - 1)
        grid_pts = full_grid[grid_idx]

        return cls(grid_idx, grid_pts)
    
@dataclass(frozen=True)
class PredictivePowerSettings:
    chemical_system: str
    n_cvar_lists: List[int]
    n_best: int
    optimizer: str
    optimizer_steps: int
    parallel_procs: int
    h5_input: str
    calculate_missing: bool
    recalc_lincomb: bool
    #lambda_c: list[int]
    #lambda_r: list[int]
    @classmethod
    def from_dict(cls, block: dict) -> 'PredictivePowerSettings':
        try:
            return cls(
                chemical_system=block["chemical_system"],
                n_cvar_lists=block["n_cvar_list"],
                n_best=block["n_best"],
                optimizer=block["optimizer"],
                optimizer_steps=block["optimizer_steps"],
                parallel_procs=block["parallel_procs"],
                h5_input=block["h5_input"],
                calculate_missing=block["calculate_missing"],
                recalc_lincomb=block["recalc_lincomb"],
                #lambda_c=block.get("lambda_c", []),
                #lambda_r=block.get("lambda_r", [])
            )
        except KeyError as e:
            raise KeyError(f"[predictive_power] missing required key: {e.args[0]}")
        
    def __post_init__(self):
        if self.n_best < 1:
            raise ValueError("n_best must be ≥ 1")
        if self.optimizer_steps < 1:
            raise ValueError("optimizer_steps must be ≥ 1")
        if self.parallel_procs < 1:
            raise ValueError("parallel_procs must be ≥ 1")

